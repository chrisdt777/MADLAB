import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const Group = () => {
  return (
    <View style={styles.dontHaveAnAccountParent}>
      <Text style={[styles.dontHaveAn, styles.createOneFlexBox]}>
        Don’t have an account?
      </Text>
      <Text style={[styles.createOne, styles.createOneFlexBox]}>
        Create one
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  createOneFlexBox: {
    textAlign: "center",
    position: "absolute",
  },
  dontHaveAn: {
    top: 3,
    left: 0,
    fontSize: FontSize.size_sm,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorLightslategray_100,
  },
  createOne: {
    top: 0,
    left: 172,
    fontSize: FontSize.size_base,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.colorHotpink,
  },
  dontHaveAnAccountParent: {
    width: 263,
    height: 24,
  },
});

export default Group;
