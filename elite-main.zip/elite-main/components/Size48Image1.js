import React, { useMemo } from "react";
import { Image, StyleSheet, ImageSourcePropType } from "react-native";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Size48Image1 = ({
  size48Image1Size48,
  size48IconPosition,
  size48IconWidth,
  size48IconHeight,
  size48IconTop,
  size48IconLeft,
}) => {
  const size48Icon1Style = useMemo(() => {
    return {
      ...getStyleValue("position", size48IconPosition),
      ...getStyleValue("width", size48IconWidth),
      ...getStyleValue("height", size48IconHeight),
      ...getStyleValue("top", size48IconTop),
      ...getStyleValue("left", size48IconLeft),
    };
  }, [
    size48IconPosition,
    size48IconWidth,
    size48IconHeight,
    size48IconTop,
    size48IconLeft,
  ]);

  return (
    <Image
      style={[styles.size48Icon, size48Icon1Style]}
      resizeMode="cover"
      source={size48Image1Size48}
    />
  );
};

const styles = StyleSheet.create({
  size48Icon: {
    width: 70,
    height: 48,
  },
});

export default Size48Image1;
