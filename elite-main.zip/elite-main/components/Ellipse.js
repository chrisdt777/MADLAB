import * as React from "react";
import { StyleSheet, View } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { Color } from "../GlobalStyles";

const Ellipse = () => {
  return (
    <LinearGradient
      style={styles.ellipseLineargradient}
      locations={[0, 0.38, 0.65, 1]}
      colors={["#544c87", "#38345c", "#25243b", "#1b1c29"]}
      useAngle={true}
      angle={182.37}
    />
  );
};

const styles = StyleSheet.create({
  ellipseLineargradient: {
    shadowColor: "rgba(0, 0, 0, 0.35)",
    shadowOffset: {
      width: -11,
      height: 6,
    },
    shadowRadius: 9,
    elevation: 9,
    shadowOpacity: 1,
    width: 70,
    height: 70,
    backgroundColor: Color.bG,
  },
});

export default Ellipse;
