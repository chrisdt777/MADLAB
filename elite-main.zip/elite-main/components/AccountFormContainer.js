import * as React from "react";
import { Text, StyleSheet, Image, View } from "react-native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const AccountFormContainer = () => {
  return (
    <View style={styles.createAccountParent}>
      <Text style={[styles.createAccount, styles.createAccountFlexBox]}>
        Create Account
      </Text>
      <Image
        style={styles.icbaselineAppleIcon}
        resizeMode="cover"
        source={require("../assets/icbaselineapple1.png")}
      />
      <Image
        style={styles.flatColorIconsgoogle}
        resizeMode="cover"
        source={require("../assets/flatcoloriconsgoogle.png")}
      />
      <View style={[styles.groupChild, styles.groupLayout]} />
      <View style={[styles.groupItem, styles.groupLayout]} />
      <Text style={[styles.email, styles.nameTypo]}>Email</Text>
      <Text style={[styles.name, styles.nameTypo]}>Name</Text>
      <View style={[styles.rectangleParent, styles.groupInnerLayout]}>
        <View style={[styles.groupInner, styles.groupInnerLayout]} />
        <Text style={styles.signIn}>Sign In</Text>
      </View>
      <Text style={[styles.forgotPassword, styles.createAccountFlexBox]}>
        Forgot Password ?
      </Text>
      <View style={[styles.rectangleView, styles.groupLayout]} />
      <Image
        style={[styles.evaeyeOffFillIcon, styles.passwordPosition]}
        resizeMode="cover"
        source={require("../assets/evaeyeofffill.png")}
      />
      <Text style={[styles.password, styles.passwordPosition]}>Password</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  createAccountFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  groupLayout: {
    height: 50,
    backgroundColor: Color.colorGray_100,
    left: 0,
    borderRadius: Border.br_3xs,
    width: 300,
    position: "absolute",
  },
  nameTypo: {
    opacity: 0.6,
    color: Color.colorBlack,
    fontFamily: FontFamily.poppinsRegular,
    left: 19,
    fontSize: FontSize.size_mini,
    textAlign: "left",
  },
  groupInnerLayout: {
    height: 36,
    width: 101,
    left: 0,
    position: "absolute",
  },
  passwordPosition: {
    top: 205,
    position: "absolute",
  },
  createAccount: {
    left: 1,
    fontSize: FontSize.size_16xl,
    lineHeight: 31,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    width: 202,
    color: Color.colorWhite,
    top: 0,
    textAlign: "left",
  },
  icbaselineAppleIcon: {
    top: 27,
    left: 266,
    width: 32,
    height: 32,
    overflow: "hidden",
    position: "absolute",
  },
  flatColorIconsgoogle: {
    top: 29,
    left: 231,
    width: 28,
    height: 28,
    overflow: "hidden",
    position: "absolute",
  },
  groupChild: {
    top: 136,
  },
  groupItem: {
    top: 80,
  },
  email: {
    top: 149,
    position: "absolute",
  },
  name: {
    top: 93,
    position: "absolute",
  },
  groupInner: {
    backgroundColor: Color.colorHotpink,
    borderRadius: Border.br_3xs,
    width: 101,
    top: 0,
  },
  signIn: {
    top: 6,
    left: 24,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    fontSize: FontSize.size_mini,
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  rectangleParent: {
    top: 255,
  },
  forgotPassword: {
    top: 262,
    left: 165,
    fontSize: FontSize.size_sm,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorLightslategray_100,
  },
  rectangleView: {
    top: 192,
  },
  evaeyeOffFillIcon: {
    left: 265,
    width: 24,
    height: 24,
    overflow: "hidden",
  },
  password: {
    opacity: 0.6,
    color: Color.colorBlack,
    fontFamily: FontFamily.poppinsRegular,
    left: 19,
    fontSize: FontSize.size_mini,
    textAlign: "left",
  },
  createAccountParent: {
    top: 406,
    left: 30,
    height: 291,
    width: 300,
    position: "absolute",
  },
});

export default AccountFormContainer;
