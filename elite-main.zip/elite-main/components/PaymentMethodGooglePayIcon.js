import * as React from "react";
import { Image, StyleSheet } from "react-native";

const PaymentMethodGooglePayIcon = () => {
  return (
    <Image
      style={styles.paymentMethodgooglepayIcon}
      resizeMode="cover"
      source={require("../assets/payment-methodgooglepay.png")}
    />
  );
};

const styles = StyleSheet.create({
  paymentMethodgooglepayIcon: {
    position: "absolute",
    top: 274,
    left: 255,
    width: 60,
    height: 41,
  },
});

export default PaymentMethodGooglePayIcon;
