import * as React from "react";
import { StyleSheet, View, Image, Text } from "react-native";
import { Color, FontSize, Border, FontFamily } from "../GlobalStyles";

const SettingsComponent = () => {
  return (
    <View style={styles.rectangleParent}>
      <View style={styles.groupChild} />
      <View style={styles.groupItem} />
      <View style={styles.excludeParent}>
        <Image
          style={styles.excludeIcon}
          resizeMode="cover"
          source={require("../assets/exclude.png")}
        />
        <View style={[styles.groupInner, styles.groupLayout]} />
        <View style={[styles.lineView, styles.groupLayout]} />
        <View style={[styles.groupChild1, styles.groupLayout]} />
        <Image
          style={[styles.solarsettingsBoldIcon, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/solarsettingsbold.png")}
        />
        <Text style={[styles.switchToSeller, styles.logOutTypo]}>
          Switch to seller account
        </Text>
        <Text style={[styles.editProfile, styles.logOutTypo]}>
          Edit Profile
        </Text>
        <Text style={[styles.logOut, styles.logOutTypo]}>Log Out</Text>
        <Text style={[styles.settings, styles.logOutTypo]}>Settings</Text>
        <Image
          style={[styles.ripencilFillIcon, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/ripencilfill.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  groupLayout: {
    height: 0,
    width: 313,
    borderTopWidth: 0.4,
    borderColor: Color.colorLightslategray_100,
    borderStyle: "solid",
    left: 4,
    position: "absolute",
  },
  iconLayout: {
    overflow: "hidden",
    height: 30,
    width: 30,
    position: "absolute",
  },
  logOutTypo: {
    textAlign: "left",
    color: Color.colorWhite,
    fontSize: FontSize.size_mini,
    position: "absolute",
  },
  groupChild: {
    top: 1,
    backgroundColor: Color.colorDarkslateblue,
    height: 248,
    borderTopRightRadius: Border.br_xl,
    borderTopLeftRadius: Border.br_xl,
    width: 360,
    left: "50%",
    marginLeft: -180,
    position: "absolute",
  },
  groupItem: {
    backgroundColor: Color.colorSteelblue_300,
    left: 0,
    top: 0,
    height: 248,
    borderTopRightRadius: Border.br_xl,
    borderTopLeftRadius: Border.br_xl,
    width: 360,
    position: "absolute",
  },
  excludeIcon: {
    width: 17,
    height: 27,
  },
  groupInner: {
    top: 101,
  },
  lineView: {
    top: 163,
  },
  groupChild1: {
    top: 41,
  },
  solarsettingsBoldIcon: {
    top: 59,
    left: 0,
  },
  switchToSeller: {
    top: 117,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 38,
    color: Color.colorWhite,
    fontSize: FontSize.size_mini,
  },
  editProfile: {
    top: 4,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 38,
    color: Color.colorWhite,
    fontSize: FontSize.size_mini,
  },
  logOut: {
    top: 178,
    left: 9,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.colorWhite,
    fontSize: FontSize.size_mini,
  },
  settings: {
    top: 62,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 38,
    color: Color.colorWhite,
    fontSize: FontSize.size_mini,
  },
  ripencilFillIcon: {
    left: 4,
    height: 30,
    width: 30,
    top: 0,
  },
  excludeParent: {
    top: 25,
    left: 19,
    width: 317,
    height: 201,
    position: "absolute",
  },
  rectangleParent: {
    top: 552,
    height: 249,
    width: 360,
    left: "50%",
    marginLeft: -180,
    position: "absolute",
  },
});

export default SettingsComponent;
