import React, { useMemo } from "react";
import { Image, StyleSheet, ImageSourcePropType } from "react-native";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const Size48Image = ({
  size48ImageSize48,
  size48IconPosition,
  size48IconWidth,
  size48IconTop,
  size48IconLeft,
  size48IconHeight,
}) => {
  const size48IconStyle = useMemo(() => {
    return {
      ...getStyleValue("position", size48IconPosition),
      ...getStyleValue("width", size48IconWidth),
      ...getStyleValue("top", size48IconTop),
      ...getStyleValue("left", size48IconLeft),
      ...getStyleValue("height", size48IconHeight),
    };
  }, [
    size48IconPosition,
    size48IconWidth,
    size48IconTop,
    size48IconLeft,
    size48IconHeight,
  ]);

  return (
    <Image
      style={[styles.size48Icon, size48IconStyle]}
      resizeMode="cover"
      source={size48ImageSize48}
    />
  );
};

const styles = StyleSheet.create({
  size48Icon: {
    width: 70,
    height: 48,
  },
});

export default Size48Image;
