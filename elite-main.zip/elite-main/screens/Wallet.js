import * as React from "react";
import { Image, StyleSheet, View, Text, TouchableOpacity } from "react-native";
import { useNavigation } from '@react-navigation/native'; // Import navigation hooks
import LinearGradient from "react-native-linear-gradient";
import Size48Image from "../components/Size48Image";
import PaymentMethodGooglePayIcon from "../components/PaymentMethodGooglePayIcon";
import Size48Image1 from "../components/Size48Image1";
import { FontSize, Color, FontFamily, Border } from "../GlobalStyles";

const Wallet = () => {
  const navigation = useNavigation(); // Hook into navigation

  return (
    <LinearGradient
      style={styles.wallet}
      locations={[0, 0.89]}
      colors={["#43427a", "#272841"]}
      useAngle={true}
      angle={180}
    >
      <TouchableOpacity onPress={() => navigation.navigate('Main')}>
        <Image
          style={styles.pharrowDownBoldIcon}
          resizeMode="cover"
          source={require("../assets/pharrowdownbold.png")}
        />
      </TouchableOpacity>
      <Text style={styles.wallet1}>WALLET</Text>
      <Text style={styles.text}>₹ 268,029</Text>
      <Image
        style={[styles.iconlyboldarrowLeft2, styles.iconlyboldarrowLayout]}
        resizeMode="cover"
        source={require("../assets/iconlyboldarrow--left-2.png")}
      />
      <Text style={[styles.totalSpend, styles.totalSpendTypo]}>
        Total Spend
      </Text>
      <Text style={[styles.transaction, styles.transactionTypo]}>
        Transaction
      </Text>
      <Text style={[styles.paymentMethods, styles.transactionTypo]}>
        Payment Methods
      </Text>
      <Text style={styles.macbookAir13}>MacBook Air 13</Text>
      <Text style={[styles.text1, styles.textTypo]}>₹ 35,000</Text>
      <Text style={[styles.text2, styles.textTypo]}>₹ 38,000</Text>
      <Text style={[styles.text3, styles.textTypo]}>₹ 6,000</Text>
      <Text style={[styles.samsungS215g, styles.samsungS215gTypo]}>
        Samsung S21+ 5G
      </Text>
      
      <Text style={[styles.titanIvLeather, styles.samsungS215gTypo]}>
        Titan IV Leather Watch
      </Text>
      <View style={styles.walletItem} />
      <View style={[styles.walletInner, styles.lineViewPosition]} />
      <View style={[styles.lineView, styles.lineViewPosition]} />
      <Size48Image
        size48ImageSize48={require("../assets/payment-methodvisa.png")}
        size48IconPosition="absolute"
        size48IconWidth={60}
        size48IconTop={274}
        size48IconLeft={65}
        size48IconHeight={41}
      />
      <PaymentMethodGooglePayIcon />
      <Image
        style={styles.icroundPlusIcon}
        resizeMode="cover"
        source={require("../assets/icroundplus.png")}
      />
      <View style={styles.rectangleView} />
      <Size48Image1
        size48Image1Size48={require("../assets/payment-methodmastercard.png")}
        size48IconPosition="absolute"
        size48IconWidth={60}
        size48IconHeight={41}
        size48IconTop={274}
        size48IconLeft={160}
      />
    
      <TouchableOpacity onPress={() => navigation.navigate('MainPage')}>
        <View style={styles.iconlyboldarrowLeft3Parent}>
          <Image
            style={[styles.iconlyboldarrowLeft3, styles.iconlyboldarrowLayout]}
            resizeMode="cover"
            source={require("../assets/iconlyboldarrow--left-3.png")}
          />
          <Text style={[styles.rewardsdiscounts, styles.totalSpendTypo]}>
            Rewards/Discounts
          </Text>
        </View>
      </TouchableOpacity>
      <View style={styles.cont}>
        <TouchableOpacity onPress={() => navigation.navigate('Main')}>
          <Image
            style={styles.contIcon}
            resizeMode="cover"
            source={require("../assets/mingcutehome3fill.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Favourites')}>
          <Image
            style={styles.contIcon}
            resizeMode="cover"
            source={require("../assets/iconamoonheartfill.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Wallet')}>
          <Image
            style={styles.contIcon}
            resizeMode="cover"
            source={require("../assets/entypowallet.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Home2')}>
          <Image
            style={styles.contIcon1}
            resizeMode="cover"
            source={require("../assets/exclude.png")}
          />
        </TouchableOpacity>
      </View>

    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  iconlyboldarrowLayout: {
    height: 20,
    width: 20,
    position: "absolute",
  },
  totalSpendTypo: {
    height: 70,
    width:200,
    fontSize: FontSize.size_base,
    color: Color.colorLightgray_100,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    left: "50%",
    position: "absolute",
  },
  transactionTypo: {
    marginLeft: -150,
    height: 50,
    width:200,
    fontSize: FontSize.size_base,
    color: Color.colorLightgray_100,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    left: "50%",
    position: "absolute",
  },
  textTypo: {
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
    color: Color.colorWhite,
    fontSize: FontSize.size_lg,
    left: "50%",
    position: "absolute",
  },
  samsungS215gTypo: {
    width: 166,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    lineHeight: 18,
    marginLeft: -150,
    textAlign: "left",
    color: Color.colorWhite,
    fontSize: FontSize.size_lg,
    left: "50%",
    position: "absolute",
  },
  lineViewPosition: {
    left: 50,
    height: 0,
    top:800,
    width: 350,
    borderTopWidth: 0.4,
    borderColor: Color.colorLightslategray_100,
    borderStyle: "solid",
    position: "absolute",
  },

  statusIcons: {
    top: 35,
    right: 15,
    width: 68,
    flexDirection: "row",
    alignItems: "center",
    opacity: 0.8,
    position: "absolute",
  },
 

  pharrowDownBoldIcon: {
    top: 42,
    left: 18,
    width: 38,
    height: 38,
    position: "absolute",
    overflow: "hidden",
  },
  wallet1: {
    marginLeft: -50,
    top: 50,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    textAlign: "left",
    color: Color.colorWhite,
    fontSize: FontSize.size_lg,
    left: "50%",
    position: "absolute",
  },
  text: {
    top: 149,
    left: 140,
    fontSize: 30,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  iconlyboldarrowLeft2: {
    top: 470,
    left: 354,
  },
  totalSpend: {
    marginLeft: -60,
    top: 123,
    width: 106,
  },
  transaction: {
    top: 470,
    width: 106,
  },
  paymentMethods: {
    top: 230,
    width: 147,
  },
  macbookAir13: {
    top: 550,
    width: 148,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    lineHeight: 18,
    marginLeft: -150,
    textAlign: "left",
    color: Color.colorWhite,
    fontSize: FontSize.size_lg,
    left: "50%",
    position: "absolute",
  },
  text1: {
    marginLeft: 72,
    top: 550,
  },
  text2: {
    marginLeft: 73,
    top: 650,
  },
  text3: {
    marginLeft: 82,
    top: 750,
  },
  samsungS215g: {
    top: 650,
  },
  titanIvLeather: {
    top: 750,
  },
  walletItem: {
    top: 525,
    height: 0,
    width: 350,
    borderTopWidth: 0.4,
    borderColor: Color.colorLightslategray_100,
    borderStyle: "solid",
    left: 53,
    position: "absolute",
  },
  walletInner: {
    top: 553,
  },
  lineView: {
    top: 618,
  },
  icroundPlusIcon: {
    top: 283,
    left: 368,
    width: 24,
    height: 24,
    position: "absolute",
    overflow: "hidden",
  },
  rectangleView: {
    top: 274,
    left: 350,
    borderRadius: Border.br_8xs,
    borderWidth: 1,
    width: 59,
    height: 41,
    borderColor: Color.colorLightslategray_100,
    borderStyle: "solid",
    position: "absolute",
  },
  iconlyboldarrowLeft3: {
    top: 3,
    left: 283,
  },
  rewardsdiscounts: {
    marginLeft: -151.5,
    top: 0,
    width: 162,
  },
  iconlyboldarrowLeft3Parent: {
    top: 380,
    width: 303,
    height: 23,
    left: 70,
    position: "absolute",
  },
  cont: {
    flexDirection: "row",
    justifyContent: "space-around",
    position: "absolute",
    bottom: 0,
    width: "100%",
    height:65,
    backgroundColor: Color.colorDarkslategray,
    paddingVertical: 10,
  },
  contIcon: {
    width: 33,
    height: 33,
  },

  wallet: {
    flex: 1,
    width: "100%",
    height: 800,
    backgroundColor: Color.bG,
    overflow: "hidden",
  },
});

export default Wallet;
