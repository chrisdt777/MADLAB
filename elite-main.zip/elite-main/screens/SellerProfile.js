import * as React from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { FontFamily, FontSize, Border, Color } from "../GlobalStyles";

const SellerProfile = () => {
  return (
    <LinearGradient
      style={styles.sellerProfile}
      locations={[0, 0.89]}
      colors={["#43427a", "#272841"]}
      useAngle={true}
      angle={180}
    >
      <Image
        style={styles.sellerProfileChild}
        resizeMode="cover"
        source={require("../assets/rectangle-34.png")}
      />
      <Text style={[styles.text, styles.textFlexBox]}>₹ 35,000</Text>
      <Image
        style={styles.unionIcon}
        resizeMode="cover"
        source={require("../assets/union.png")}
      />
      <Text style={[styles.h36m, styles.h36mTypo]}>2h : 36m : 16s</Text>
      <Image
        style={[styles.sellerProfileItem, styles.sellerLayout]}
        resizeMode="cover"
        source={require("../assets/rectangle-321.png")}
      />
      <Image
        style={[styles.sellerProfileInner, styles.sellerLayout]}
        resizeMode="cover"
        source={require("../assets/rectangle-35.png")}
      />
      <Image
        style={[styles.rectangleIcon, styles.sellerLayout]}
        resizeMode="cover"
        source={require("../assets/rectangle-36.png")}
      />
      <View style={styles.rectangleView} />
      <View style={styles.sellerProfileChild1} />
      <Image
        style={[styles.mingcutehome3FillIcon, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/mingcutehome3fill.png")}
      />
      <Image
        style={[styles.iconamoonheartFill, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/iconamoonheartfill.png")}
      />
      <Image
        style={[styles.entypowalletIcon, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/entypowallet.png")}
      />
      <Image
        style={styles.pharrowDownBoldIcon}
        resizeMode="cover"
        source={require("../assets/pharrowdownbold.png")}
      />
      <Text style={[styles.bidHistory, styles.hyderabadClr]}>Bid History</Text>
      <View style={[styles.rectangleParent, styles.groupChildLayout]}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Text style={[styles.createAuction, styles.text1Typo]}>
          Create Auction
        </Text>
      </View>
      <Text style={[styles.text1, styles.text1Typo]}>20</Text>
      <Text style={[styles.totalItems, styles.hyderabadClr]}>Total Items</Text>
      <Image
        style={styles.jammenuIcon}
        resizeMode="cover"
        source={require("../assets/jammenu.png")}
      />
      <Image
        style={[styles.sellerProfileChild2, styles.sellerLayout]}
        resizeMode="cover"
        source={require("../assets/rectangle-301.png")}
      />
      <Text style={[styles.macbookAir13, styles.textFlexBox]}>
        MacBook Air 13
      </Text>
      <Text
        style={[styles.airpods2ndGen, styles.text2Typo]}
      >{`AirPods (2nd gen) `}</Text>
      <Text style={[styles.iphone12, styles.textFlexBox]}>{`iphone 12 `}</Text>
      <Text
        style={[styles.iphone14Pro, styles.textFlexBox]}
      >{`iphone 14 Pro `}</Text>
      <Text style={[styles.text2, styles.text2Typo]}>₹ 10,000</Text>
      <Text style={[styles.text3, styles.textTypo]}>₹ 45,000</Text>
      <Text style={[styles.text4, styles.textTypo]}>₹ 80,000</Text>
      <Image
        style={[styles.mditickCircleIcon, styles.mditickIconLayout]}
        resizeMode="cover"
        source={require("../assets/mditickcircle.png")}
      />
      <Image
        style={[styles.mditickCircleIcon1, styles.mditickIconLayout]}
        resizeMode="cover"
        source={require("../assets/mditickcircle.png")}
      />
      <Image
        style={[styles.mditickCircleIcon2, styles.mditickIconLayout]}
        resizeMode="cover"
        source={require("../assets/mditickcircle.png")}
      />
      <Image
        style={[styles.mditickCircleIcon3, styles.mditickIconLayout]}
        resizeMode="cover"
        source={require("../assets/mditickcircle.png")}
      />
      <Text style={[styles.sellerProfile1, styles.text1Typo]}>
        SELLER PROFILE
      </Text>
      <Image
        style={styles.ellipseIcon}
        resizeMode="cover"
        source={require("../assets/ellipse-7.png")}
      />
      <Text style={[styles.karanPatel, styles.textFlexBox]}>Karan Patel</Text>
      <Text style={[styles.hyderabad, styles.hyderabadClr]}>Hyderabad</Text>
      <Image
        style={styles.sellerProfileChild3}
        resizeMode="cover"
        source={require("../assets/ellipse-241.png")}
      />
      <Image
        style={styles.sellerProfileChild4}
        resizeMode="cover"
        source={require("../assets/ellipse-71.png")}
      />
      <View style={[styles.statusIcons, styles.iconPosition]}>
        <Image
          style={styles.networkSignalDark}
          resizeMode="cover"
          source={require("../assets/network-signal--dark.png")}
        />
        <Image
          style={styles.wifiSignalDark}
          resizeMode="cover"
          source={require("../assets/wifi-signal--dark.png")}
        />
        <Image
          style={styles.batteryDark}
          resizeMode="cover"
          source={require("../assets/battery--dark.png")}
        />
      </View>
      <Image
        style={[styles.icon, styles.iconPosition]}
        resizeMode="cover"
        source={require("../assets/941.png")}
      />
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  textFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  h36mTypo: {
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_xs,
  },
  sellerLayout: {
    left: 19,
    height: 67,
    width: 317,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  iconLayout: {
    height: 33,
    top: 735,
    width: 33,
    position: "absolute",
    overflow: "hidden",
  },
  hyderabadClr: {
    color: Color.colorLightgray_100,
    textAlign: "left",
    position: "absolute",
  },
  groupChildLayout: {
    height: 36,
    width: 134,
    position: "absolute",
  },
  text1Typo: {
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  text2Typo: {
    top: 517,
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_xs,
    left: "50%",
    position: "absolute",
  },
  textTypo: {
    marginLeft: 88,
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_xs,
    left: "50%",
    position: "absolute",
  },
  mditickIconLayout: {
    height: 24,
    width: 24,
    left: 320,
    position: "absolute",
    overflow: "hidden",
  },
  iconPosition: {
    opacity: 0.8,
    position: "absolute",
  },
  sellerProfileChild: {
    top: 395,
    height: 67,
    width: 317,
    borderRadius: Border.br_3xs,
    left: "50%",
    marginLeft: -161,
    position: "absolute",
  },
  text: {
    top: 442,
    left: 264,
    color: Color.colorWhite,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textAlign: "left",
    fontSize: FontSize.size_xs,
  },
  unionIcon: {
    borderRadius: 1,
    width: 6,
    height: 11,
  },
  h36m: {
    top: 400,
    left: 244,
    letterSpacing: 0.1,
    color: Color.colorGray_300,
    textAlign: "left",
    position: "absolute",
  },
  sellerProfileItem: {
    top: 545,
  },
  sellerProfileInner: {
    top: 620,
  },
  rectangleIcon: {
    top: 695,
  },
  rectangleView: {
    top: 726,
    shadowColor: "rgba(0, 0, 0, 0.35)",
    shadowOffset: {
      width: 0,
      height: -7,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    backgroundColor: Color.colorDarkslategray,
    width: 360,
    height: 74,
    left: 0,
    position: "absolute",
  },
  sellerProfileChild1: {
    top: 785,
    left: 93,
    borderRadius: Border.br_8xs,
    backgroundColor: Color.colorSlategray,
    width: 174,
    height: 5,
    position: "absolute",
  },
  mingcutehome3FillIcon: {
    left: 35,
  },
  iconamoonheartFill: {
    left: 126,
  },
  entypowalletIcon: {
    left: 217,
  },
  pharrowDownBoldIcon: {
    top: 42,
    left: 18,
    width: 38,
    height: 38,
    position: "absolute",
    overflow: "hidden",
  },
  bidHistory: {
    top: 369,
    fontSize: FontSize.size_3xs,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    left: "50%",
    marginLeft: -161,
    color: Color.colorLightgray_100,
  },
  groupChild: {
    top: 0,
    backgroundColor: Color.colorHotpink,
    left: 0,
    borderRadius: Border.br_3xs,
    width: 134,
  },
  createAuction: {
    top: 7,
    left: 12,
    fontSize: FontSize.size_sm,
    fontWeight: "700",
  },
  rectangleParent: {
    top: 302,
    left: 185,
  },
  text1: {
    marginLeft: -85,
    top: 299,
    fontSize: FontSize.size_sm,
    fontWeight: "700",
    left: "50%",
  },
  totalItems: {
    top: 320,
    left: 71,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_xs,
  },
  jammenuIcon: {
    top: 39,
    left: 303,
    width: 41,
    height: 41,
    position: "absolute",
    overflow: "hidden",
  },
  sellerProfileChild2: {
    top: 470,
  },
  macbookAir13: {
    top: 448,
    lineHeight: 12,
    width: 108,
    marginLeft: -153,
    color: Color.colorWhite,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textAlign: "left",
    fontSize: FontSize.size_xs,
    left: "50%",
  },
  airpods2ndGen: {
    marginLeft: -153,
  },
  iphone12: {
    top: 594,
    marginLeft: -153,
    color: Color.colorWhite,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textAlign: "left",
    fontSize: FontSize.size_xs,
    left: "50%",
  },
  iphone14Pro: {
    top: 669,
    marginLeft: -153,
    color: Color.colorWhite,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textAlign: "left",
    fontSize: FontSize.size_xs,
    left: "50%",
  },
  text2: {
    marginLeft: 91,
  },
  text3: {
    top: 594,
  },
  text4: {
    top: 669,
  },
  mditickCircleIcon: {
    top: 464,
  },
  mditickCircleIcon1: {
    top: 539,
  },
  mditickCircleIcon2: {
    top: 614,
  },
  mditickCircleIcon3: {
    top: 689,
  },
  sellerProfile1: {
    marginLeft: -67,
    top: 47,
    fontSize: FontSize.size_lg,
    left: "50%",
  },
  ellipseIcon: {
    marginLeft: 121,
    top: 738,
    width: 30,
    height: 30,
    left: "50%",
    position: "absolute",
  },
  karanPatel: {
    marginLeft: -48,
    top: 246,
    fontSize: FontSize.size_base,
    color: Color.colorWhite,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textAlign: "left",
    left: "50%",
  },
  hyderabad: {
    marginLeft: -34,
    top: 269,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_xs,
    left: "50%",
  },
  sellerProfileChild3: {
    marginLeft: -73,
    top: 94,
    width: 146,
    height: 146,
    left: "50%",
    position: "absolute",
  },
  sellerProfileChild4: {
    marginLeft: -66,
    top: 102,
    width: 131,
    height: 131,
    left: "50%",
    position: "absolute",
  },
  networkSignalDark: {
    width: 20,
    height: 14,
  },
  wifiSignalDark: {
    width: 16,
    marginLeft: 4,
    height: 14,
  },
  batteryDark: {
    width: 25,
    height: 12,
    marginLeft: 4,
  },
  statusIcons: {
    top: 14,
    right: 15,
    width: 68,
    flexDirection: "row",
    alignItems: "center",
  },
  icon: {
    marginTop: -387,
    top: "50%",
    height: 15,
    width: 33,
    opacity: 0.8,
    left: "50%",
    marginLeft: -161,
  },
  sellerProfile: {
    flex: 1,
    width: "100%",
    height: 800,
    backgroundColor: Color.bG,
    overflow: "hidden",
  },
});

export default SellerProfile;
