import * as React from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { Color, FontFamily, Border, FontSize } from "../GlobalStyles";

const Home1 = () => {
  return (
    <LinearGradient
      style={styles.home2}
      locations={[0, 0.89]}
      colors={["#43427a", "#272841"]}
      useAngle={true}
      angle={180}
    >
      <Image
        style={styles.home2Child}
        resizeMode="cover"
        source={require("../assets/rectangle-34.png")}
      />
      <Text style={[styles.text, styles.textClr]}>₹ 35,000</Text>
      <Image
        style={styles.unionIcon}
        resizeMode="cover"
        source={require("../assets/union.png")}
      />
      <Text style={[styles.h36m, styles.allTypo1]}>2h : 36m : 16s</Text>
      <Image
        style={[styles.home2Item, styles.home2ItemLayout]}
        resizeMode="cover"
        source={require("../assets/rectangle-32.png")}
      />
      <View style={styles.home2Inner} />
      <Image
        style={styles.excludeIcon}
        resizeMode="cover"
        source={require("../assets/exclude.png")}
      />
      <View style={styles.rectangleView} />
      <Image
        style={[styles.mingcutehome3FillIcon, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/mingcutehome3fill.png")}
      />
      <Image
        style={[styles.iconamoonheartFill, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/iconamoonheartfill.png")}
      />
      <Image
        style={[styles.entypowalletIcon, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/entypowallet.png")}
      />
      <Image
        style={styles.pharrowDownBoldIcon}
        resizeMode="cover"
        source={require("../assets/pharrowdownbold.png")}
      />
      <Text style={[styles.buyerProfile, styles.text3Typo]}>BUYER PROFILE</Text>
      <Image
        style={styles.ellipseIcon}
        resizeMode="cover"
        source={require("../assets/ellipse-9.png")}
      />
      <Text style={[styles.akshayVerma, styles.textClr]}>Akshay Verma</Text>
      <Text style={[styles.electronicsHome, styles.text1Position]}>
        Electronics , Home Decor , Accessories
      </Text>
      <Text style={[styles.text1, styles.text1Position]}>
        <Text style={styles.textTypo}>{`< `}</Text>
        <Text style={styles.text3Typo}>₹</Text>
        <Text style={styles.textTypo}> 50,000</Text>
      </Text>
      <Text style={[styles.interests, styles.allTypo]}>Interests</Text>
      <Text style={[styles.budgetRange, styles.allTypo]}>Budget Range</Text>
      <Text style={[styles.bidsHistory, styles.bidsHistoryPosition]}>
        Bids History
      </Text>
      <Text style={[styles.all, styles.allTypo]}>All</Text>
      <Text style={[styles.banglore, styles.allTypo]}>Banglore</Text>
      <View style={[styles.rectangleParent, styles.groupChildLayout]}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Text style={[styles.inviteToBid, styles.text5Typo]}>
          Invite to Bid
        </Text>
      </View>
      <View style={styles.parent}>
        <Text style={[styles.text5, styles.text5Typo]}>6</Text>
        <Text style={[styles.auctionWins, styles.allTypo]}>Auction Wins</Text>
      </View>
      <Image
        style={styles.jammenuIcon}
        resizeMode="cover"
        source={require("../assets/jammenu.png")}
      />
      <Image
        style={[styles.rectangleIcon, styles.home2ItemLayout]}
        resizeMode="cover"
        source={require("../assets/rectangle-30.png")}
      />
      <Text style={[styles.macbookAir13, styles.textClr]}>MacBook Air 13</Text>
      <Text style={[styles.samsungS215g, styles.text6Typo]}>
        Samsung S21+ 5G
      </Text>
      <Text style={[styles.text6, styles.text6Typo]}>₹ 38,000</Text>
      <Image
        style={[styles.mditickCircleIcon, styles.mditickIconLayout]}
        resizeMode="cover"
        source={require("../assets/mditickcircle.png")}
      />
      <Image
        style={[styles.mditickCircleIcon1, styles.mditickIconLayout]}
        resizeMode="cover"
        source={require("../assets/mditickcircle.png")}
      />
      <Image
        style={styles.home2Child1}
        resizeMode="cover"
        source={require("../assets/ellipse-91.png")}
      />
      <Image
        style={styles.home2Child2}
        resizeMode="cover"
        source={require("../assets/ellipse-241.png")}
      />
      <Image
        style={[styles.iconlyboldarrowLeft2, styles.bidsHistoryPosition]}
        resizeMode="cover"
        source={require("../assets/iconlyboldarrow--left-2.png")}
      />
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  textClr: {
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
  },
  allTypo1: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  home2ItemLayout: {
    left: 19,
    height: 67,
    width: 317,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  iconLayout: {
    height: 33,
    width: 33,
    top: 735,
    position: "absolute",
    overflow: "hidden",
  },
  text3Typo: {
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
  },
  text1Position: {
    fontSize: FontSize.size_mini,
    textAlign: "left",
    color: Color.colorWhite,
    left: "50%",
    marginLeft: -161,
    position: "absolute",
  },
  allTypo: {
    color: Color.colorLightgray_100,
    textAlign: "left",
    fontSize: FontSize.size_xs,
  },
  bidsHistoryPosition: {
    top: 497,
    position: "absolute",
  },
  groupChildLayout: {
    height: 36,
    width: 105,
    position: "absolute",
  },
  text5Typo: {
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  text6Typo: {
    top: 645,
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_xs,
    left: "50%",
    position: "absolute",
  },
  mditickIconLayout: {
    height: 24,
    width: 24,
    left: 320,
    position: "absolute",
    overflow: "hidden",
  },
  home2Child: {
    top: 523,
    height: 67,
    width: 317,
    borderRadius: Border.br_3xs,
    left: "50%",
    marginLeft: -161,
    position: "absolute",
  },
  text: {
    top: 570,
    left: 264,
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_xs,
  },
  unionIcon: {
    borderRadius: 1,
    width: 6,
    height: 11,
  },
  h36m: {
    top: 528,
    left: 244,
    letterSpacing: 0.1,
    color: Color.colorGray_300,
    textAlign: "left",
    fontSize: FontSize.size_xs,
  },
  home2Item: {
    top: 673,
  },
  home2Inner: {
    top: 726,
    shadowColor: "rgba(0, 0, 0, 0.35)",
    shadowOffset: {
      width: 0,
      height: -7,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    backgroundColor: Color.colorDarkslategray,
    width: 360,
    height: 74,
    left: 0,
    position: "absolute",
  },
  excludeIcon: {
    width: 17,
    height: 27,
  },
  rectangleView: {
    top: 785,
    left: 93,
    borderRadius: Border.br_8xs,
    backgroundColor: Color.colorSlategray,
    width: 174,
    height: 5,
    position: "absolute",
  },
  mingcutehome3FillIcon: {
    left: 35,
  },
  iconamoonheartFill: {
    left: 126,
  },
  entypowalletIcon: {
    left: 217,
  },
  pharrowDownBoldIcon: {
    top: 42,
    left: 18,
    width: 38,
    height: 38,
    position: "absolute",
    overflow: "hidden",
  },
  buyerProfile: {
    marginLeft: -67,
    top: 47,
    fontSize: FontSize.size_lg,
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
    left: "50%",
  },
  ellipseIcon: {
    marginLeft: -66,
    top: 102,
    width: 131,
    height: 131,
    left: "50%",
    position: "absolute",
  },
  akshayVerma: {
    marginLeft: -60,
    top: 246,
    fontSize: FontSize.size_base,
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    left: "50%",
  },
  electronicsHome: {
    top: 396,
    width: 293,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  textTypo: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  text1: {
    top: 454,
  },
  interests: {
    top: 381,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorLightgray_100,
    left: "50%",
    marginLeft: -161,
    position: "absolute",
  },
  budgetRange: {
    top: 439,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorLightgray_100,
    left: "50%",
    marginLeft: -161,
    position: "absolute",
  },
  bidsHistory: {
    color: Color.colorLightgray_100,
    textAlign: "left",
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.poppinsRegular,
    left: "50%",
    marginLeft: -161,
  },
  all: {
    marginLeft: 123,
    top: 498,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
    left: "50%",
  },
  banglore: {
    marginLeft: -27,
    top: 269,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorLightgray_100,
    left: "50%",
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.colorHotpink,
    top: 0,
    left: 0,
    borderRadius: Border.br_3xs,
    width: 105,
  },
  inviteToBid: {
    top: 7,
    left: 10,
  },
  rectangleParent: {
    top: 302,
    left: 185,
  },
  text5: {
    marginLeft: -5,
    top: 0,
    left: "50%",
  },
  auctionWins: {
    top: 21,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorLightgray_100,
    left: 0,
    position: "absolute",
  },
  parent: {
    marginLeft: -109,
    top: 299,
    width: 78,
    height: 39,
    left: "50%",
    position: "absolute",
  },
  jammenuIcon: {
    top: 39,
    left: 303,
    width: 41,
    height: 41,
    position: "absolute",
    overflow: "hidden",
  },
  rectangleIcon: {
    top: 598,
  },
  macbookAir13: {
    top: 576,
    lineHeight: 12,
    width: 108,
    marginLeft: -153,
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_xs,
    left: "50%",
  },
  samsungS215g: {
    marginLeft: -153,
  },
  text6: {
    marginLeft: 84,
  },
  mditickCircleIcon: {
    top: 592,
  },
  mditickCircleIcon1: {
    top: 667,
  },
  home2Child1: {
    marginLeft: 121,
    top: 738,
    width: 30,
    height: 30,
    left: "50%",
    position: "absolute",
  },
  home2Child2: {
    marginLeft: -73,
    top: 94,
    width: 146,
    height: 146,
    left: "50%",
    position: "absolute",
  },
  iconlyboldarrowLeft2: {
    left: 318,
    width: 20,
    height: 20,
  },
  home2: {
    flex: 1,
    width: "100%",
    height: 800,
    backgroundColor: Color.bG,
    overflow: "hidden",
  },
});

export default Home1;
