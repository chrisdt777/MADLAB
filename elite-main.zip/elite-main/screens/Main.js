import * as React from "react";
import { Image, StyleSheet, Text, View, TouchableOpacity,TextInput,ScrollView } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useNavigation } from '@react-navigation/native';
import { FontFamily, Color, Border, FontSize } from "../GlobalStyles";

const Main = () => {
  const navigation = useNavigation();
  
  return (
    <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
    <LinearGradient
      style={styles.main}
      locations={[0, 0.89]}
      colors={["#43427a", "#272841"]}
      useAngle={true}
      angle={180}
    >
      <Image
        style={styles.image19Icon}
        resizeMode="cover"
        source={require("../assets/image-19.png")}
      />
      <Text style={[styles.hotBids, styles.hotBidsTypo]}>HOT BIDS</Text>
      <Image
        style={[styles.mainChild, styles.mainLayout]}
        resizeMode="cover"
        source={require("../assets/rectangle-6.png")}
      />
      <Image
        style={[styles.mainItem, styles.mainLayout]}
        resizeMode="cover"
        source={require("../assets/rectangle-7.png")}
      />
      <View style={[styles.mainInner, styles.mainInnerShadowBox]} />
      <View style={[styles.rectangleView, styles.mainInnerShadowBox]} />
      <Image
        style={styles.iconParkSolidfire}
        resizeMode="cover"
        source={require("../assets/iconparksolidfire.png")}
      />
      <View style={[styles.mainChild1, styles.mainChild1Position]} />
      <Text style={[styles.search, styles.liteTypo]}>Search</Text>
      <View style={styles.mainChild2} />
      <View style={[styles.mainChild3, styles.mainChildLayout]} />
      <View style={[styles.mainChild4, styles.mainChildLayout]} />
      <View style={[styles.mainChild5, styles.mainChildLayout]} />
      <View style={styles.mainChild6} />
      <Image
        style={[styles.ionnotificationsCircleIcon, styles.litePosition]}
        resizeMode="cover"
        source={require("../assets/ionnotificationscircle.png")}
      />
      <TouchableOpacity onPress={() => navigation.navigate('LiveAuction')}>
        <View style={[styles.rectangleParent, styles.groupChildLayout]}>
          <View style={[styles.groupChild, styles.groupChildLayout]} />
          <Text style={[styles.placeABid, styles.searchTypo]}>Place a bid</Text>
        </View>
      </TouchableOpacity>
      <Text style={styles.text}>₹ 35,000</Text>
      <Image
        style={styles.unionIcon}
        resizeMode="cover"
        source={require("../assets/union1.png")}
      />
      <Image
        style={styles.unionIcon1}
        resizeMode="cover"
        source={require("../assets/union2.png")}
      />
      <Image
        style={styles.unionIcon2}
        resizeMode="cover"
        source={require("../assets/union2.png")}
      />
      <Text style={[styles.text1, styles.textTypo]}>₹ 79,000</Text>
      <Text style={[styles.text2, styles.textTypo]}>₹ 15,000</Text>
      <Text style={styles.h36m}>2h : 36m : 16s</Text>
      <Text style={[styles.h46m, styles.h46mTypo]}>23h : 46m : 10s</Text>
      <Text style={[styles.h25m, styles.h46mTypo]}>15h : 25m : 10s</Text>
      <LinearGradient
        style={[styles.rectangleLineargradient, styles.mainChild1Position]}
        locations={[0.13, 1]}
        colors={["#32213f", "rgba(50, 33, 63, 0.42)"]}
        useAngle={true}
        angle={180}
      />
      <Image
        style={styles.majesticonssearchLine}
        resizeMode="cover"
        source={require("../assets/majesticonssearchline.png")}
      />
      <Text style={[styles.lite, styles.header]}>èlite</Text>
      <Image
        style={[styles.image22Icon, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/image-22.png")}
      />
      <Image
        style={[styles.image20Icon, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/image-20.png")}
      />
      <View style={styles.liveAuctionItem} />
      
      <View style={styles.cont}>
        <TouchableOpacity onPress={() => navigation.navigate('Main')}>
          <Image
            style={styles.contIcon}
            resizeMode="cover"
            source={require("../assets/mingcutehome3fill.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Favourites')}>
          <Image
            style={styles.contIcon}
            resizeMode="cover"
            source={require("../assets/iconamoonheartfill.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Wallet')}>
          <Image
            style={styles.contIcon}
            resizeMode="cover"
            source={require("../assets/entypowallet.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Home2')}>
          <Image
            style={styles.contIcon1}
            resizeMode="cover"
            source={require("../assets/exclude.png")}
          />
        </TouchableOpacity>
      </View>

      
    </LinearGradient>
    </ScrollView>
  );
};


const styles = StyleSheet.create({
  hotBidsTypo: {
    textAlign: "left",
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    color: Color.colorWhite,
  },
  mainLayout: {
    height: 200,
    width: 200,
    borderRadius: Border.br_mini,
    position: "absolute",
  },
  mainInnerShadowBox: {
    height: 33,
    backgroundColor: Color.colorDarkslategray,
    borderBottomLeftRadius: Border.br_mini,
    borderBottomRightRadius: Border.br_mini,
    shadowOpacity: 1,
    elevation: 19,
    shadowRadius: 19,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    width: 210,
    position: "absolute",
  },
  mainChild1Position: {
    left: "5.28%",
    bottom: "80.25%",
    top: "12%",
    height: "5.75%",
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  liteTypo: {
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
    top: 130,
    left: 100,
    fontSize: 15,
  },
  mainChildLayout: {
    backgroundColor: Color.colorGainsboro_100,
    height: 3,
    width: 66,
    borderRadius: Border.br_8xs,
    top: 410,
    position: "absolute",
  },
  ionnotificationsCircleIcon: {
    width: 53,
    height: 53,
    overflow: "hidden",
    top: 30,
    left: 20,
  },
  litePosition: {
    position: "absolute",
    top: 40,
    left: 380,
  },
  groupChildLayout: {
    height: 36,
    width: 101,
    position: "absolute",
  },
  searchTypo: {
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  textTypo: {
    fontSize: FontSize.size_3xs,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  h46mTypo: {
    letterSpacing: 0.1,
    fontSize: FontSize.size_2xs,
    color: Color.colorGray_300,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  iconLayout: {
    height: 140,
    position: "absolute",
  },
  image19Icon: {
    top: 195,
    borderRadius: Border.br_mid,
    width: 400,
    height: 230,
    left: 23,
    position: "absolute",
  },
  hotBids: {
    top: 445,
    left: 190,
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  mainChild: {
    top: 680,
    left: 20,
  },
  mainItem: {
    top: 710,
    left: 240,
  },
  mainInner: {
    top: 627,
    left: 20,
  },
  rectangleView: {
    top: 652,
    left: 245,
  },
  iconParkSolidfire: {
    top: 445,
    left: 165,
    width: 19,
    height: 19,
    position: "absolute",
    overflow: "hidden",
  },
  frameIcon: {
    top: 700,
    width: 470,
    height: 74,
    left: 0,
    position: "absolute",
  },
  mainChild1: {
    width: "89.17%",
    right: "5.56%",
    backgroundColor: "rgba(141, 143, 184, 0.59)",
    borderRadius: Border.br_3xs,
  },
  search: {
    top: 115,
    left: 81,
    color: Color.colorGray_200,
    width: 161,
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  mainChild2: {
    left: 40,
    backgroundColor: "#fbfbfb",
    height: 3,
    width: 66,
    borderRadius: Border.br_8xs,
    top: 410,
    position: "absolute",
  },
  mainChild3: {
    left: 140,
  },
  mainChild4: {
    left: 240,
  },
  mainChild5: {
    left: 340,
  },
  mainChild6: {
    left: 40,
    backgroundColor: "rgba(108, 109, 155, 0.32)",
    width: 355,
    height: 50,
    top: 342,
    borderBottomLeftRadius: Border.br_mini,
    borderBottomRightRadius: Border.br_mini,
    position: "absolute",
  },
  groupChild: {
    top: 23,
    backgroundColor: Color.colorHotpink,
    borderRadius: Border.br_3xs,
    left: 45,
  },
  placeABid: {
    top: 30,
    left: 58,
    textAlign: "left",
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    color: Color.colorWhite,
  },
  rectangleParent: {
    top: 326,
    left: 232,
  },
  text: {
    top: 365,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_mini,
    left: 50,
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  unionIcon: {
    top: 373,
    left: 133,
    width: 9,
    height: 15,
    borderRadius: 1,
  },
  
  unionIcon1: {
    top: 650,
    left: 320,
    width: 6,
    height: 10,
    borderRadius: 1,
  },
  unionIcon2: {
    top: 613,
    left: 93,
    width: 6,
    height: 10,
    borderRadius: 1,
  },
  text1: {
    top: 634,
    left: 37,
    fontSize: FontSize.size_3xs,
  },
  text2: {
    top: 661,
    left: 262,
  },
  h36m: {
    letterSpacing: 0.2,
    color: Color.colorGray_300,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_mini,
    left: 50,
    top: 343,
    textAlign: "left",
    position: "absolute",
  },
  h46m: {
    top: 634,
    left: 120,
  },
  h25m: {
    top: 661,
    left: 342,
  },
  rectangleLineargradient: {
    position: "absolute",
    top: 0,
    width: "14.17%",
    right: "80.56%",
    borderRadius: Border.br_3xs,
    backgroundColor: Color.bG,
  },
  majesticonssearchLine: {
    top: 120,
    left: 32,
    width: 41,
    height: 43,
    position: "absolute",
    overflow: "hidden",
  },
  statusIcons: {
    top: 14,
    right: 15,
    width: 68,
    flexDirection: "row",
    alignItems: "center",
  },
  lite: {
    fontSize: 36,
    width: 212,
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
    height: 74,
    left: 30,
    color: Color.colorWhite,
    top: 5,
  },
  image22Icon: {
    top: 510,
    borderRadius: 22,
    width: 190,
    left: 245,
  },
  image20Icon: {
    top: 485,
    width: 190,
    borderRadius: Border.br_mini,
    height: 170,
    left: 21,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 60,
    backgroundColor: '#43427a',
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#272841',
  },
  footerIcon: {
    width: 40,
    height: 40,
  },
  liveAuctionItem: {
    top: 880,
    shadowColor: "rgba(0, 0, 0, 0.1)",
    shadowOffset: {
      width: 0,
      height: -7,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    backgroundColor: Color.colorDarkslategray,
    width: 460,
    height: 74,
    left: 0,
    position: "absolute",
  },
  cont: {
    flexDirection: "row",
    justifyContent: "space-around",
    position: "absolute",
    bottom: 0,
    width: "100%",
    height:65,
    backgroundColor: Color.colorDarkslategray,
    paddingVertical: 10,
  },
  contIcon: {
    width: 33,
    height: 33,
  },
  main: {
    flex: 1,
    width: "100%",
    height: 800,
    backgroundColor: Color.bG,
    overflow: "hidden",
    position: "relative",
  },
});

export default Main;
