import * as React from "react";
import { Image, StyleSheet, Text, TouchableOpacity, View, TextInput, ScrollView } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { FontFamily, Color, FontSize } from "../GlobalStyles";
import { useNavigation } from '@react-navigation/native';

const Welcome = () => {
  const navigation = useNavigation();
  return (
    <LinearGradient
      style={styles.welcome}
      locations={[0, 0.89]}
      colors={["#43427a", "#272841"]}
      useAngle={true}
      angle={180}
    >
      <Image
        style={styles.welcomeChild}
        resizeMode="cover"
        source={require("../assets/ellipse-25.png")}
      />
      <Image
        style={styles.welcomeItem}
        resizeMode="cover"
        source={require("../assets/ellipse-24.png")}
      />
         <Image
        style={styles.welcomeItem}
        resizeMode="cover"
        source={require("../assets/ellipse-24.png")}
      />

      <TouchableOpacity onPress={() => navigation.navigate('CreateAccount')}>
   
    <Text style={styles.getStarted}>GET STARTED</Text>
      </TouchableOpacity>
      
      <Text
        style={[styles.buySell, styles.buySellTypo]}
      >{`Buy & sell exquisite products,\nOne stop for all your needs.`}</Text>
      <Text style={[styles.biddingMadeEasy, styles.buySellTypo]}>
        Bidding Made Easy
      </Text>
      <Image
        style={[styles.welcomeInner, styles.welcomeLayout]}
        resizeMode="cover"
        source={require("../assets/ellipse-22.png")}
      />
      <Image
        style={styles.ellipseIcon}
        resizeMode="cover"
        source={require("../assets/ellipse-21.png")}
      />
      <Image
        style={styles.welcomeChild1}
        resizeMode="cover"
        source={require("../assets/ellipse-15.png")}
      />
      <Image
        style={[styles.welcomeChild2, styles.welcomeLayout]}
        resizeMode="cover"
        source={require("../assets/ellipse-23.png")}
      />
      <Image
        style={styles.welcomeChild3}
        resizeMode="cover"
        source={require("../assets/ellipse-20.png")}
      />
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  buySellTypo: {//bidding and intro
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textAlign: "left",
    color: Color.colorWhite,
    left: 40,
    position: "absolute",
  },
  welcomeLayout: {//ellipses
    height: 27,
    width: 27,
    position: "absolute",
  },
  welcomeChild: {
    top: -161,
    left: -93,
    width: 453,
    height: 447,
    position: "absolute",
  },
  welcomeItem: {//get started ellipse
    top: 665,
    width: 70,
    height: 70,
    left: 17,
    position: "absolute",
  },
  getStarted: {
    top: 680, // Adjust the top position as needed
    width: 200, // Adjust the width to ensure it's clickable
    height: 50, // Adjust the height to ensure it's clickable
    fontSize: FontSize.size_lg,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
    alignSelf: "center", // Center the text horizontally
    justifyContent: "center",
    left:30, // Center the text vertically
  },
  buySell: {
    top: 585,
    fontSize: FontSize.size_base,
    width: 278,
    height: 53,
  },
  biddingMadeEasy: {
    top: 450,
    fontSize: 33,
    lineHeight: 44,
    width: 300,
  },
  welcomeInner: {
    top: 66,
    left: 204,
  },
  ellipseIcon: {
    top: 121,
    left: 192,
    width: 41,
    height: 41,
    position: "absolute",
  },
  welcomeChild1: {
    top: 36,
    left: 236,
    width: 85,
    height: 85,
    position: "absolute",
  },
  welcomeChild2: {
    top: 30,
    left: 187,
  },
  welcomeChild3: {
    top: 88,
    left: 292,
    width: 49,
    height: 49,
    position: "absolute",
  },
  welcome: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
    backgroundColor: Color.bG,
  },
});

export default Welcome;
