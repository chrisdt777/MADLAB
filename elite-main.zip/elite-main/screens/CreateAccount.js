import * as React from "react";
import { Image, StyleSheet, Text, View, TouchableOpacity, TextInput, ScrollView } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { FontFamily, Color, Border, FontSize } from "../GlobalStyles";
import { useNavigation } from '@react-navigation/native';

const CreateAccount = () => {
  const navigation = useNavigation();

  const handleSignInPress = () => {
    navigation.navigate('SignIn');
  };

  return (
    <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
      <LinearGradient
        style={styles.createAccount}
        locations={[0, 0.89]}
        colors={["#43427a", "#272841"]}
        useAngle={true}
        angle={180}
      >
        <Text style={styles.createAccountText}>Create Account</Text>
        <Image
          style={styles.createAccountChild}
          resizeMode="cover"
          source={require("../assets/ellipse-25.png")}
        />
        <Image
          style={[styles.createAccountItem, styles.createLayout]}
          resizeMode="cover"
          source={require("../assets/ellipse-22.png")}
        />
        <Image
          style={styles.createAccountInner}
          resizeMode="cover"
          source={require("../assets/ellipse-21.png")}
        />
        <Image
          style={styles.ellipseIcon}
          resizeMode="cover"
          source={require("../assets/ellipse-15.png")}
        />
        <Image
          style={[styles.createAccountChild1, styles.createLayout]}
          resizeMode="cover"
          source={require("../assets/ellipse-23.png")}
        />
        <Image
          style={styles.createAccountChild2}
          resizeMode="cover"
          source={require("../assets/ellipse-20.png")}
        />

        {/* Input Boxes */}
        <View style={styles.inputContainer}>
          <View style={styles.inputBox}>
            <TextInput
              style={styles.inputText}
              placeholder="Name"
              placeholderTextColor={Color.colorBlack}
            />
          </View>
          <View style={styles.inputBox}>
            <TextInput
              style={styles.inputText}
              placeholder="Email"
              placeholderTextColor={Color.colorBlack}
            />
          </View>
          <View style={styles.inputBox}>
            <TextInput
              style={styles.inputText}
              placeholder="Password"
              placeholderTextColor={Color.colorBlack}
              secureTextEntry
            />
           </View>
        </View>

        <View style={styles.eye}>
            <Image
               style={[styles.evaeyeOffFillIcon, styles.passwordPosition]}
              resizeMode="cover"
            source={require("../assets/evaeyeofffill.png")}
            />
        </View>

        {/* Login Button */}
        <TouchableOpacity onPress={handleSignInPress}>
           <View style={styles.rectangleParent}>
           <View style={styles.groupChild} />
           <Text style={styles.login}>SignUp</Text>
          </View>
        </TouchableOpacity>

    
        <Image
          style={styles.icbaselineAppleIcon}
          resizeMode="cover"
          source={require("../assets/icbaselineapple1.png")}
        />
        <Image
          style={styles.flatColorIconsgoogle}
          resizeMode="cover"
          source={require("../assets/flatcoloriconsgoogle.png")}
        />
        <TouchableOpacity onPress={handleSignInPress}>
          <View style={styles.createAccountContainer}>
            <Text style={[styles.alreadyHaveAn, styles.signInFlexBox]}>
              Already have an account?
            </Text>
            <Text style={[styles.signIn, styles.signInFlexBox]}>Sign In</Text>
          </View>
        </TouchableOpacity>
        
      </LinearGradient>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  createLayout: {//ellipses
    height: 27,
    width: 27,
    position: "absolute",
  },
  welcomeBackTypo: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  signInFlexBox: {
    textAlign: "center",
    position: "absolute",
  },
  createAccountChild: {//biggger ellipse
    top: -161,
    left: -93,
    width: 453,
    height: 447,
    position: "absolute",
  },
  createAccountItem: {
    top: 66,
    left: 204,
  },
  createAccountInner: {//ellipse
    top: 121,
    left: 192,
    width: 41,
    height: 41,
    position: "absolute",
  },
  ellipseIcon: {
    top: 36,
    left: 236,
    width: 85,
    height: 85,
    position: "absolute",
  },
  createAccountChild1: {
    top: 30,
    left: 187,
  },
  createAccountChild2: {
    top: 88,
    left: 292,
    width: 49,
    height: 49,
    position: "absolute",
  },
  createAccountText: {
    color: "white",
    top:280,
    fontSize: 33, // Adjust as needed
    textAlign: "left",
    right:-20,
    width:200,
    marginTop: 100, // Adjust as needed
  },
  inputContainer: {//All the three containers
    marginTop: 290,// Adjust as needed
    left:0,
    alignItems: "center",
   
  },
  inputBox: {
    width: 390,
    height: 50,
    backgroundColor: Color.colorGray_100,
    borderRadius: Border.br_3xs,
    marginVertical: 10,
    justifyContent: "center",
    paddingHorizontal: 10,
  },
  inputText: {
    opacity: 0.6,
    color: Color.colorBlack,
    fontFamily: FontFamily.poppinsRegular,
  },
  rectangleParent: {
    height: 40,
    width: 101,
    left: 150, // Adjust as needed
    top: 50, // Adjust as needed
    position: "relative",
  },
  groupChild: {//pink box
    backgroundColor: Color.colorHotpink,
    borderRadius: Border.br_3xs,
    height: 36,
    width: 101,
    left: -110,
    top: -65,
    position: "absolute",
  },
  login: {
    top: -60,
    left: -90,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    fontSize: 13,
    textAlign:"center",
    color: Color.colorWhite,
    position: "absolute",
  },
  forgotPassword: {
    top: 390,
    left: 300,
    fontSize: FontSize.size_sm,
    color: Color.colorLightslategray_100,
  },
  icbaselineAppleIcon: {
    top: 475,
    left: 377,
    width: 32,
    height: 32,
    position: "absolute",
    overflow: "hidden",
  },
  flatColorIconsgoogle: {
    top: 477,
    left: 337,
    width: 28,
    height: 28,
    position: "absolute",
    overflow: "hidden",
  },
  createAccountContainer: {
    position: "absolute",
    bottom: 50,
    alignSelf: "center",
  },
  alreadyHaveAn: {
    top: 50,
    fontSize: FontSize.size_sm,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorLightslategray_100,
    left: -145,
  },
  signIn: {
    left: 69,
    fontSize: FontSize.size_base,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.colorHotpink,
    top: 48,
  },
  eye: {
    top:-45,
    left:380,
  },
  createAccount: {
    flex: 1,
    width: "100%",
    minHeight: 800,
    backgroundColor: Color.bG,
  },
});

export default CreateAccount;
