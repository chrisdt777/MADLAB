import React from "react";
import { Image, StyleSheet, Text, View, TouchableOpacity, TextInput , ScrollView} from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { FontFamily, Color, Border, FontSize } from "../GlobalStyles";
import { useNavigation } from '@react-navigation/native';


const SignIn = () => {
  const navigation = useNavigation();

  const handleLoginPress = () => {
    navigation.navigate('Main');
  };

  const handleForgotPasswordPress = () => {
    navigation.navigate('ForgotPassword');
  };

  return (
    <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
    <LinearGradient
      style={styles.signIn}
      locations={[0, 0.89]}
      colors={["#43427a", "#272841"]}
      useAngle={true}
      angle={180}
    >
      <Image
        style={styles.signInChild}
        resizeMode="cover"
        source={require("../assets/ellipse-25.png")}
      />
      <Image
        style={[styles.signInItem, styles.signLayout]}
        resizeMode="cover"
        source={require("../assets/ellipse-22.png")}
      />
      <Image
        style={styles.signInInner}
        resizeMode="cover"
        source={require("../assets/ellipse-21.png")}
      />
      <Image
        style={styles.ellipseIcon}
        resizeMode="cover"
        source={require("../assets/ellipse-15.png")}
      />
      <Image
        style={[styles.signInChild1, styles.signLayout]}
        resizeMode="cover"
        source={require("../assets/ellipse-23.png")}
      />
      <Image
        style={styles.signInChild2}
        resizeMode="cover"
        source={require("../assets/ellipse-20.png")}
      />
      <View style={styles.signInParent}>
        <Text style={styles.signIn1}>Sign In</Text>
        <Text style={[styles.welcomeBack, styles.welcomeBackTypo]}>
          Welcome back
        </Text>
      </View>
      <TouchableOpacity onPress={handleLoginPress}>
        <View style={styles.rectangleParent}>
          <View style={styles.groupChild} />
          <Text style={styles.login}>Login</Text>
        </View>
      </TouchableOpacity>
      <TouchableOpacity onPress={handleForgotPasswordPress}>
        <Text style={[styles.forgotPassword, styles.welcomeBackTypo]}>
          Forgot Password ?
        </Text>
      </TouchableOpacity>

      <Image
        style={styles.icbaselineAppleIcon}
        resizeMode="cover"
        source={require("../assets/icbaselineapple1.png")}
      />
      <Image
        style={styles.flatColorIconsgoogle}
        resizeMode="cover"
        source={require("../assets/flatcoloriconsgoogle.png")}
      />

      {/* Input Boxes */}
      <View style={styles.inputContainer}>
        <View style={styles.inputBox}>
          <TextInput
            style={styles.inputText}
            placeholder="Email"
            placeholderTextColor={Color.colorBlack}
          />
        </View>
        <View style={styles.inputBox}>
          <TextInput
            style={styles.inputText}
            placeholder="Password"
            placeholderTextColor={Color.colorBlack}
            secureTextEntry
          />
        </View>
      </View>

      <Image
        style={[styles.evaeyeOffFillIcon, styles.passwordPosition]}
        resizeMode="cover"
        source={require("../assets/evaeyeofffill.png")}
      />

    </LinearGradient>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  signLayout: {
    height: 27,
    width: 27,
    position: "absolute",
  },
  welcomeBackTypo: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  signInChild3Layout: {
    height: 50,
    width: 300,
    backgroundColor: Color.colorGray_100,
    borderRadius: Border.br_3xs,
    left: 30,
    position: "absolute",
  },
  emailTypo: {
    opacity: 0.6,
    color: Color.colorBlack,
    fontFamily: FontFamily.poppinsRegular,
    left: 49,
    fontSize: FontSize.size_mini,
    textAlign: "left",
  },
  passwordPosition: {
    top: 615,
    position: "absolute",
  },
  signInChild: {
    top: -141,
    left: -93,
    width: 453,
    height: 447,
    position: "absolute",
  },
  signInItem: {
    top: 66,
    left: 204,
  },
  signInInner: {
    top: 121,
    left: 192,
    width: 41,
    height: 41,
    position: "absolute",
  },
  ellipseIcon: {
    top: 36,
    left: 236,
    width: 85,
    height: 85,
    position: "absolute",
  },
  signInChild1: {
    top: 30,
    left: 187,
  },
  signInChild2: {
    top: 88,
    left: 292,
    width: 49,
    height: 49,
    position: "absolute",
  },
  signIn1: {
    fontSize: FontSize.size_16xl,
    lineHeight: 44,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    textAlign: "left",
    color: Color.colorWhite,
    top: 0,
    left: 0,
    width: 160,
    position: "absolute",
  },
  welcomeBack: {
    top: 60,
    fontSize: FontSize.size_smi,
    color: Color.colorLightslategray_200,
    left: 0,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  signInParent: {
    top: 430,
    height: 66,
    width: 200,
    left: 30,
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.colorHotpink,
    borderRadius: Border.br_3xs,
    height: 36,
    width: 101,
    left: 20,
    top: 70,
    position: "absolute",
  },
  login: {
    top: 75,
    left: 45,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    fontSize: FontSize.size_mini,
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  rectangleParent: {
    top: 600,
    height: 40,
    width: 101,
    left: 27,
    position: "absolute",
  },
  forgotPassword: {
    top: 665,
    left: 260,
    fontSize: FontSize.size_sm,
    color: Color.colorLightslategray_100,
  },
  icbaselineAppleIcon: {
    top: 490,
    left: 370,
    width: 32,
    height: 32,
    position: "absolute",
    overflow: "hidden",
  },
  flatColorIconsgoogle: {
    top: 490,
    left: 330,
    width: 28,
    height: 28,
    position: "absolute",
    overflow: "hidden",
  },
  rectangleView: {
    top: 542,
  },
  email: {
    top: 555,
    position: "absolute",
  },
  signInChild3: {
    top: 598,
    
  },
  password: {
    opacity: 0.6,
    color: Color.colorBlack,
    fontFamily: FontFamily.poppinsRegular,
    left: 49,
    fontSize: FontSize.size_mini,
    textAlign: "left",
  },
  evaeyeOffFillIcon: {
    left: 380,
    width: 24,
    height: 24,
    overflow: "hidden",
  },
  signInChild3Layout: {
    height: 50,  // Increase the height
    width: 300,  // Increase the width
    backgroundColor: Color.colorGray_100,
    borderRadius: Border.br_3xs,
    left: 30,
    position: "absolute",
  },
  inputContainer: {
    marginTop: 290, // Adjust as needed
    left: 0,
    alignItems: "center",
  },
  inputBox: {
    width: 390,
    height: 50,
    top:230,
    backgroundColor: Color.colorGray_100,
    borderRadius: Border.br_3xs,
    marginVertical: 10,
    justifyContent: "center",
    paddingHorizontal: 10,
  },
  inputText: {
    opacity: 0.6,
    color: Color.colorBlack,
    fontFamily: FontFamily.poppinsRegular,
  },
  signIn: {
    flex: 1,
    width: "100%",
    height: 800,
    backgroundColor: Color.bG,
    overflow: "hidden",
  },
});

export default SignIn;
