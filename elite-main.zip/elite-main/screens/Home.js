// screens/HomeScreen.js
import * as React from "react";
import { useEffect } from "react";
import { Text, StyleSheet, Image, View,TextInput, ScrollView } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const Home = ({ navigation }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      navigation.navigate('Welcome');
    }, 3000); // Navigate after 3 seconds

    return () => clearTimeout(timer); // Clean up the timer
  }, [navigation]);
 
  return (
    <LinearGradient
      style={styles.home}
      locations={[0, 0.89]}
      colors={["#43427a", "#272841"]}
      useAngle={true}
      angle={180}
    >
      <Text style={[styles.craftedForThe, styles.liteFlexBox]}>
        Crafted for the elite.
      </Text>
      <Text style={[styles.lite, styles.liteFlexBox]}>èlite</Text>
      <Image
        style={styles.homeChild}
        resizeMode="cover"
        source={require("../assets/ellipse-25.png")}
      />
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  liteFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  craftedForThe: {//Crafted for the elite
    marginRight: 10,
    top: 580,
    left: "32%",
    fontSize: FontSize.size_base,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.colorLightslategray_100,
    width: 250,
    height: 25,
  },
  lite: {//èlite
    top: 480,
    marginLeft: 100,
    left: 65,
    fontSize: 55, // Adjusted font size
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorWhite,
    width: 199,
    height: 100,
  },
  homeChild: {//pink ellipse
    top: -150,
    left: -93,
    width: 453,
    height: 447,
    position: "absolute",
  }, 
  home: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
    backgroundColor: Color.bG,
  },
});

export default Home;
