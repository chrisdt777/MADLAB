import * as React from "react";
import { Image, StyleSheet, Text, View, TouchableOpacity } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useNavigation } from '@react-navigation/native';
import { FontFamily, Color, Border, FontSize } from "../GlobalStyles";

const LiveAuction = () => {
  const navigation = useNavigation();
  return (
    <LinearGradient
      style={styles.liveAuction}
      locations={[0, 0.89]}
      colors={["#43427a", "#272841"]}
      useAngle={true}
      angle={180}
    >
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Image
          style={styles.pharrowDownBoldIcon}
          resizeMode="cover"
          source={require("../assets/pharrowdownbold.png")}
        />
      </TouchableOpacity>

      <Text style={[styles.liveAuction1, styles.h36mFlexBox]}>
        LIVE AUCTION
      </Text>

      <Image
        style={styles.iconamoonheartFill}
        resizeMode="cover"
        source={require("../assets/iconamoonheartfill1.png")}
      />
      <View style={[styles.liveAuctionChild, styles.image19IconLayout]} />
      <View style={[styles.rectangleParent, styles.groupChildLayout]}>
        <View style={[styles.groupChild, styles.groupChildPosition]} />
        <TouchableOpacity onPress={() => navigation.navigate('PlaceABid')}>
          <Text style={[styles.placeABid, styles.h36mFlexBox]}>Place a bid</Text>
        </TouchableOpacity>
      </View>
      <View style={[styles.auctionEndingInParent, styles.h36mLayout]}>
        <Text style={[styles.auctionEndingIn, styles.auctionEndingInTypo]}>
          Auction ending in
        </Text>
        <Text style={[styles.h36m, styles.h36mTypo]}>2h : 36m : 16s</Text>
      </View>

      <View style={styles.cont}>
        <TouchableOpacity onPress={() => navigation.navigate('Home')}>
          <Image
            style={styles.contIcon}
            resizeMode="cover"
            source={require("../assets/mingcutehome3fill.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Favorites')}>
          <Image
            style={styles.contIcon}
            resizeMode="cover"
            source={require("../assets/iconamoonheartfill.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Wallet')}>
          <Image
            style={styles.contIcon}
            resizeMode="cover"
            source={require("../assets/entypowallet.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Home2')}>
          <Image
            style={styles.contIcon1}
            resizeMode="cover"
            source={require("../assets/exclude.png")}
          />
        </TouchableOpacity>
      </View>

      <Image
        style={styles.ellipseIcon}
        resizeMode="cover"
        source={require("../assets/ellipse-6.png")}
      />
      <Text style={styles.seller}>Seller</Text>
      <Text style={[styles.description, styles.descriptionTypo]}>
        Description
      </Text>
      
      <Text style={[styles.theShoeBringsContainer, styles.auctionEndingInTypo1]}>
        <Text style={styles.theShoeBrings}>
          The shoe brings genuine University Blue leather to the ankle, heel,
          toe and outsole, with black on the Swoosh and collar and contrasting
          white on the quarter panel, midsole, tongue and toe box. A black Wings
          logo with University Blue branding on the tongue helps finish off the
          model's clean and classic detailing....
        </Text>
        <Text style={styles.readMore}>read more</Text>
      </Text>
      <Text style={[styles.john, styles.textTypo]}>John</Text>
      <Text style={[styles.airJordan1, styles.airJordan1Position]}>
        Air Jordan 1 Retro High OG
      </Text>
      <Text style={[styles.currentBid, styles.airJordan1Position]}>
        Current Bid
      </Text>
      <Text style={[styles.text, styles.textTypo]}>₹ 35,000</Text>
      <Image
        style={styles.unionIcon}
        resizeMode="cover"
        source={require("../assets/union3.png")}
      />
      <View style={styles.frameView} />
      <Image
        style={[styles.image19Icon, styles.image19IconLayout]}
        resizeMode="cover"
        source={require("../assets/image-191.png")}
      />
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  h36mFlexBox: {
    textAlign: "left",
    color: Color.colorWhite,
  },
  image19IconLayout: {
    width: 410,
    position: "absolute",
  },
  groupChildLayout: {
    height: 36,
    width: 105,
    position: "absolute",
  },
  groupChildPosition: {
    top: 0,
    left: 60,
  },
  h36mLayout: {
    width: 103,
    position: "absolute",
  },
  auctionEndingInTypo: {
    fontSize: 15,
    textAlign: "left",
    position: "absolute",
    fontFamily: FontFamily.poppinsMedium,
  },
  h36mTypo: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  iconPosition: {
    top: 900,
    height: 33,
    width: 33,
    position: "absolute",
    overflow: "hidden",
  },
  descriptionTypo: {
    top: 620,
    left: 30,
    color: Color.colorLightgray_100,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: 20,
    textAlign: "left",
    position: "absolute",
  },
  descriptionTypo1: {
    top: 620,
    left: 100,
    color: Color.colorLightgray_100,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    position: "absolute",
  },
  textTypo: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  airJordan1Position: {
    left: 21,
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  pharrowDownBoldIcon: {
    top: 40,
    left: 18,
    width: 38,
    height: 38,
    position: "absolute",
    overflow: "hidden",
  },
  liveAuction1: {
    marginLeft: -80,
    top: 43,
    fontSize: FontSize.size_lg,
    fontFamily: FontFamily.poppinsRegular,
    fontWeight: "700",
    left: "50%",
    textAlign: "left",
    position: "absolute",
  },
  statusIcons: {
    top: 14,
    right: 15,
    width: 68,
    flexDirection: "row",
    alignItems: "center",
    opacity: 0.8,
    position: "absolute",
  },
  icon: {
    marginTop: -387,
    marginLeft: -161,
    top: "50%",
    height: 15,
    width: 33,
    opacity: 0.8,
    left: "50%",
    position: "absolute",
  },
  iconamoonheartFill: {
    top: 35,
    left: 391,
    height: 33,
    width: 33,
    position: "absolute",
    overflow: "hidden",
  },
  liveAuctionChild: {
    top: 437,
    left: 20,
    backgroundColor: Color.colorSteelblue_200,
    borderStyle: "solid",
    borderColor: Color.colorThistle,
    borderWidth: 1,
    height: 60,
    borderRadius: Border.br_3xs,
  },
  groupChild: {
    backgroundColor: Color.colorHotpink,
    left: 0,
    height: 36,
    width: 130,
    position: "absolute",
    borderRadius: Border.br_3xs,
  },
  placeABid: {
    top: 7,
    left: 80,
    fontSize: FontSize.size_sm,
    width: 200,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    position: "absolute",
  },
  rectangleParent: {
    top: 449,
    left: 216,
  },
  auctionEndingIn: {
    fontFamily: FontFamily.poppinsRegular,
    color: "rgba(255, 255, 255, 0.8)",
    width: 200,
    left: 0,
    top: 0,
  },
  h36m: {
    top: 21,
    letterSpacing: 0.2,
    fontSize: FontSize.size_mini,
    width: 150,
    position: "absolute",
    left: 0,
    textAlign: "left",
    color: Color.colorWhite,
  },
  auctionEndingInParent: {
    top: 446,
    left: 36,
    height: 42,
  },
  ellipseIcon: {
    width: 60,
    height: 60,
    left: 26,
    top: 555,
    position: "absolute",
  },
  seller: {
    color: Color.colorLightgray_100,
    left: 100,
    top: 550,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: 18,
    textAlign: "left",
    position: "absolute",
  },
  description: {
    left: 26,
  },
  bidsHistory: {
    left: 100,
  },
  theShoeBrings: {
    color: Color.colorWhite,
    fontFamily:FontFamily.poppinsRegular,
  },
  readMore: {
    color: Color.colorHotpink,
  },
  theShoeBringsContainer: {
    top: 630,
    width: 310,
    left: 26,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
  },
  john: {
    top: 575,
    fontWeight: 'bold',
    fontSize: 17,
    left: 100,
    fontWeight: "600",
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  airJordan1: {
    top: 390,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: 22,
  },
  currentBid: {
    top: 510,
    fontSize: 20,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  text: {
    top: 514,
    left: 310,
    fontSize: 18,
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  unionIcon: {
    top: 525,
    borderRadius: 1,
    width: 8,
    height: 14,
    left: 410,
  },
  frameView: {
    top: 79,
    left: 256,
    width: 100,
    height: 100,
    position: "absolute",
    overflow: "hidden",
  },
  image19Icon: {
    top: 115,
    borderRadius: Border.br_mid,
    height: 257,
    left: 20,
  },
  auctionEndingInTypo1: {
    fontSize: 15,
    textAlign: "justify",
    position: "absolute",
    fontFamily: FontFamily.poppinsRegular,
    color: "rgba(255, 255, 255, 0.8)",
    width: 400,
    left: 30,
    top: 660,
  },
  cont: {
    flexDirection: "row",
    justifyContent: "space-around",
    position: "absolute",
    bottom: 0,
    width: "100%",
    height:65,
    backgroundColor: Color.colorDarkslategray,
    paddingVertical: 10,
  },
  contIcon: {
    width: 33,
    height: 33,
  },

  liveAuction: {
    flex: 1,
    width: "100%",
    height: "100%",
    backgroundColor: Color.bG,
    overflow: "hidden",
  },
});

export default LiveAuction;
