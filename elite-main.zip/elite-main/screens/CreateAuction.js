import * as React from "react";
import { StyleSheet, View, Image, Text, ScrollView, TouchableOpacity, TextInput } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const CreateAuction = ({ navigation }) => {
  return (
    <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
      <LinearGradient
        style={styles.createAuction}
        locations={[0, 0.89]}
        colors={["#43427a", "#272841"]}
        useAngle={true}
        angle={180}
      >
        <View style={styles.createAuctionChild} />
       
        <TouchableOpacity onPress={() => navigation.navigate('Home2')}>
          <Image
            style={styles.pharrowDownBoldIcon}
            resizeMode="cover"
            source={require("../assets/pharrowdownbold.png")}
          />
        </TouchableOpacity>
        <Text style={[styles.createAuction1, styles.createPosition]}>
          CREATE AUCTION
        </Text>
        <View style={[styles.createAuctionInner, styles.createChildPosition]} />
        <Text style={styles.uploadProductImages}>Upload product images</Text>
        
        <TouchableOpacity onPress={() => navigation.navigate('PlaceABid')}>
        <View style={[styles.rectangleParent, styles.groupChildLayout]}>
          <View style={[styles.groupChild, styles.groupChildLayout]} />
          <Text style={[styles.createAuction2, styles.createPosition]}>
            Create Auction
          </Text>
        </View>
          </TouchableOpacity>
        
        <View style={[styles.rectangleView, styles.rectangleViewLayout]} />
        <View style={[styles.createAuctionChild1, styles.rectangleViewLayout]} />
        <View style={styles.createAuctionChild2} />
    
       
        <View style={[styles.createAuctionChild4, styles.createChildPosition]} />
        <View style={styles.createAuctionChild4}>
            <TextInput
              style={styles.createChildPosition}
              placeholder="Enter Your Product Name"
              placeholderTextColor={Color.colorWhite}
            />
        </View>
        <View style={styles.description}>
            <TextInput
              style={styles.descriptionTypo}
              placeholder="Enter Your Description"
              placeholderTextColor={Color.colorWhite}
              
            />
        </View>
        <Text style={[styles.auctionEndsAt, styles.descriptionTypo]}>
          Auction ends at
        </Text>
        <Text style={[styles.description, styles.descriptionTypo]}>
          Description
        </Text>
        <Text style={[styles.startingBid, styles.descriptionTypo]}>
          Starting Bid
        </Text>
        <Text style={[styles.productName, styles.descriptionTypo]}>
          Product Name
        </Text>
        <Text style={[styles.limit100Words, styles.amountTypo]}>
          (Limit: 100 words)
        </Text>
        <Text style={[styles.text, styles.textTypo]}>10</Text>
        <Text style={[styles.text1, styles.textTypo]}>00</Text>
        <Text style={styles.text2}>:</Text>
        <Text style={[styles.am, styles.textTypo]}>AM</Text>
        <Text style={[styles.limit24hrs, styles.amountTypo]}>(Limit: 24hrs)</Text>
        
        <View style={styles.createAuctionChild3}>
            <TextInput
              style={styles.createChildPosition}
              placeholder="Enter Amount"
              placeholderTextColor={Color.colorWhite}
            />
        </View>
       
        <View style={[styles.statusIcons, styles.iconPosition]}>
     
        </View>
       
        <Image
          style={styles.bximageIcon}
          resizeMode="cover"
          source={require("../assets/bximage.png")}
        />
        <Image
          style={styles.bximageIcon1}
          resizeMode="cover"
          source={require("../assets/bximage1.png")}
        />
      </LinearGradient>
    </ScrollView>
  );
};
const styles = StyleSheet.create({
  createPosition: {
    textAlign: "left",
    left: "50%",
    position: "absolute",
  },
  createChildPosition: {
    width: 400,
    marginLeft: -200,
    backgroundColor: Color.colorSteelblue_100,
    left: "50%",
    position: "absolute",
  },
  groupChildLayout: {
    height: 36,
    width: 274,
    position: "absolute",
  },
  rectangleViewLayout: {
    width: 41,
    borderRadius: Border.br_8xs,
    top: 565,
    height: 38,
    backgroundColor: Color.colorSteelblue_100,
    left: "37%",
    position: "absolute",
  },
  descriptionTypo: {
    height: 50,
    width: 210,
    fontSize: FontSize.size_mini,
    color: Color.colorLightgray_100,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    left: "50%",
    position: "absolute",
  },
  amountTypo: {
    color: Color.colorLightgray_200,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  textTypo: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_base,
    color: Color.colorWhite,
  },
  text3Position: {
    marginLeft: -127,
    textAlign: "left",
    left: "50%",
    position: "absolute",
  },
  iconPosition: {
    opacity: 0.8,
    position: "absolute",
  },
  createAuctionChild: {
    top: 639,
    width: 400,
    height: 161,
    backgroundColor: Color.colorSteelblue_100,
    color: Color.colorLightgray_200,
    borderRadius: Border.br_3xs,
    left: "36%",
    marginLeft: -136,
    position: "absolute",
  },
  createAuctionItem: {
    top: 702,
    backgroundColor: "#282942",
    width: 360,
    height: 98,
    left: 0,
    position: "absolute",
  },
  pharrowDownBoldIcon: {
    top: 42,
    left: 18,
    width: 38,
    height: 38,
    position: "absolute",
    overflow: "hidden",
  },
  createAuction1: {
    marginLeft: -88,
    top: 47,
    fontSize: FontSize.size_lg,
    color: Color.colorWhite,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    textAlign: "left",
  },
  createAuctionInner: {
    top: 103,
    borderRadius: Border.br_mini,
    height: 257,
  },
  uploadProductImages: {
    marginLeft: -96,
    top: 237,
    color: Color.colorLightgray_100,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_base,
    textAlign: "left",
    left: "50%",
    position: "absolute",
  },
  groupChild: {
    top: 100,
    backgroundColor: Color.colorHotpink,
    left: 50,
    borderRadius: Border.br_3xs,
  },
  createAuction2: {
    marginLeft: -15,
    top: 105,
    fontSize: FontSize.size_sm,
    color: Color.colorWhite,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    textAlign: "left",
  },
  rectangleParent: {
    top: 722,
    left: 43,
  },
  rectangleView: {
    marginLeft: -136,
  },
  createAuctionChild1: {
    marginLeft: -85,
  },
  createAuctionChild2: {
    marginLeft: -90,
    width: 40,
    borderRadius: Border.br_8xs,
    top: 565,
    height: 38,
    backgroundColor: Color.colorSteelblue_100,
    left: "50%",
    position: "absolute",
  },
  createAuctionChild3: {
    top: 440,
    height: 38,
    borderRadius: Border.br_3xs,
  },
  createAuctionChild4: {
    top: 396,
    height: 38,
    borderRadius: Border.br_3xs,
  },
  auctionEndsAt: {
    top: 533,
    marginLeft: -200,
  },
  description: {
    top: 614,
    marginLeft: -197,
  },
  startingBid: {
    top: 452,
    marginLeft: -200,
  },
  productName: {
    top: 368,
    marginLeft: -200,
    width: 200,
    fontSize: FontSize.size_mini,
  },
  limit100Words: {
    marginLeft: -80,
    top: 617,
    textAlign: "left",
    left: "50%",
    position: "absolute",
  },
  text: {
    marginLeft: -188,
    top: 568,
    fontWeight: "600",
    textAlign: "left",
    left: "50%",
    position: "absolute",
  },
  text1: {
    marginLeft: -136,
    top: 569,
    fontWeight: "600",
    textAlign: "left",
    left: "50%",
    position: "absolute",
  },
  text2: {
    marginLeft: -152,
    top: 567,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_base,
    textAlign: "left",
    color: Color.colorWhite,
    left: "50%",
    position: "absolute",
  },
  am: {
    marginLeft: -86,
    top: 567,
    fontWeight: "600",
    textAlign: "left",
    left: "50%",
    position: "absolute",
  },
  limit24hrs: {
    marginLeft: -50,
    top: 536,
    textAlign: "left",
    left: "50%",
    position: "absolute",
  },
  exampleMacbook: {
    top: 406,
    color: Color.colorLightgray_200,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  amount: {
    marginLeft: -112,
    top: 487,
    textAlign: "left",
    left: "50%",
    position: "absolute",
  },
  text3: {
    top: 484,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_base,
    color: Color.colorWhite,
  },
  networkSignalDark: {
    width: 20,
    height: 14,
  },
  wifiSignalDark: {
    width: 16,
    marginLeft: 4,
    height: 14,
  },
  batteryDark: {
    width: 25,
    height: 12,
    marginLeft: 4,
  },
  statusIcons: {
    top: 14,
    right: 15,
    width: 68,
    flexDirection: "row",
    alignItems: "center",
  },
  icon: {
    marginTop: -387,
    marginLeft: -161,
    top: "50%",
    width: 33,
    height: 15,
    left: "50%",
    opacity: 0.8,
  },
  bximageIcon: {
    top: 184,
    left: 210,
    width: 52,
    height: 52,
    position: "absolute",
    overflow: "hidden",
  },
  bximageIcon1: {
    top: 192,
    left: 230,
    width: 48,
    height: 48,
    position: "absolute",
    overflow: "hidden",
  },
  createAuction: {
    flex: 1,
    width: "100%",
    height: 800,
    backgroundColor: Color.bG,
    overflow: "hidden",
  },
});

export default CreateAuction;
