import * as React from "react";
import { Image, StyleSheet, View } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { Color } from "../GlobalStyles";

const CreateAccount1 = () => {
  return (
    <LinearGradient
      style={styles.createAccount}
      locations={[0, 0.89]}
      colors={["#43427a", "#272841"]}
      useAngle={true}
      angle={180}
    >
      <Image
        style={styles.createAccountChild}
        resizeMode="cover"
        source={require("../assets/ellipse-242.png")}
      />
      <Image
        style={styles.createAccountItem}
        resizeMode="cover"
        source={require("../assets/ellipse-151.png")}
      />
      <Image
        style={styles.createAccountInner}
        resizeMode="cover"
        source={require("../assets/ellipse-202.png")}
      />
      <Image
        style={styles.ellipseIcon}
        resizeMode="cover"
        source={require("../assets/ellipse-222.png")}
      />
      <Image
        style={styles.createAccountChild1}
        resizeMode="cover"
        source={require("../assets/ellipse-212.png")}
      />
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  createAccountChild: {
    top: 191,
    left: 18,
    width: 70,
    height: 70,
    position: "absolute",
  },
  createAccountItem: {
    top: -15,
    left: -13,
    width: 85,
    height: 85,
    position: "absolute",
  },
  createAccountInner: {
    top: 661,
    left: 325,
    width: 49,
    height: 49,
    position: "absolute",
  },
  ellipseIcon: {
    top: 649,
    left: 26,
    width: 27,
    height: 27,
    position: "absolute",
  },
  createAccountChild1: {
    top: 100,
    left: 270,
    width: 41,
    height: 41,
    position: "absolute",
  },
  createAccount: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
    backgroundColor: Color.bG,
  },
});

export default CreateAccount1;
