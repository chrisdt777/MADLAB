import * as React from "react";
import { Image, StyleSheet, View } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { Color } from "../GlobalStyles";

const Welcome1 = () => {
  return (
    <LinearGradient
      style={styles.welcome}
      locations={[0, 0.89]}
      colors={["#43427a", "#272841"]}
      useAngle={true}
      angle={180}
    >
      <Image
        style={styles.welcomeChild}
        resizeMode="cover"
        source={require("../assets/ellipse-25.png")}
      />
      <Image
        style={styles.welcomeItem}
        resizeMode="cover"
        source={require("../assets/ellipse-24.png")}
      />
      <Image
        style={[styles.welcomeInner, styles.welcomeLayout]}
        resizeMode="cover"
        source={require("../assets/ellipse-221.png")}
      />
      <Image
        style={styles.ellipseIcon}
        resizeMode="cover"
        source={require("../assets/ellipse-211.png")}
      />
      <Image
        style={styles.welcomeChild1}
        resizeMode="cover"
        source={require("../assets/ellipse-15.png")}
      />
      <Image
        style={[styles.welcomeChild2, styles.welcomeLayout]}
        resizeMode="cover"
        source={require("../assets/ellipse-23.png")}
      />
      <Image
        style={styles.welcomeChild3}
        resizeMode="cover"
        source={require("../assets/ellipse-20.png")}
      />
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  welcomeLayout: {
    height: 27,
    width: 27,
    position: "absolute",
  },
  welcomeChild: {
    top: -141,
    left: -93,
    width: 453,
    height: 447,
    position: "absolute",
  },
  welcomeItem: {
    top: 677,
    left: 30,
    width: 70,
    height: 70,
    position: "absolute",
  },
  welcomeInner: {
    top: 66,
    left: 204,
  },
  ellipseIcon: {
    top: 121,
    left: 192,
    width: 41,
    height: 41,
    position: "absolute",
  },
  welcomeChild1: {
    top: 36,
    left: 236,
    width: 85,
    height: 85,
    position: "absolute",
  },
  welcomeChild2: {
    top: 30,
    left: 187,
  },
  welcomeChild3: {
    top: 88,
    left: 292,
    width: 49,
    height: 49,
    position: "absolute",
  },
  welcome: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
    backgroundColor: Color.bG,
  },
});

export default Welcome1;
