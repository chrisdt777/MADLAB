import React from "react";
import { Image, StyleSheet, Text, View, TouchableOpacity, TextInput, ScrollView } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { Color, FontFamily, Border, FontSize } from "../GlobalStyles";
import { useNavigation } from '@react-navigation/native';

const Home1 = () => {
  const navigation = useNavigation();

  return (
    <LinearGradient
      style={styles.home2}
      locations={[0, 0.89]}
      colors={["#43427a", "#272841"]}
      useAngle={true}
      angle={180}
    >
      <Image
        style={styles.home2Child}
        resizeMode="cover"
        source={require("../assets/rectangle-34.png")}
      />
      <Text style={[styles.text, styles.textClr]}>₹ 35,000</Text>
      <Image
        style={styles.unionIcon}
        resizeMode="cover"
        source={require("../assets/union.png")}
      />
      <Text style={[styles.h36m, styles.allTypo1]}>2h : 36m : 16s</Text>
      <Image
        style={[styles.home2Item, styles.home2ItemLayout]}
        resizeMode="cover"
        source={require("../assets/rectangle-32.png")}
      />
      <TouchableOpacity onPress={() => navigation.navigate('Main')}>
        <Image
          style={styles.pharrowDownBoldIcon}
          resizeMode="cover"
          source={require("../assets/pharrowdownbold.png")}
        />
      </TouchableOpacity>
      <Text style={[styles.buyerProfile, styles.text3Typo]}>BUYER PROFILE</Text>
      <Image
        style={styles.ellipseIcon}
        resizeMode="cover"
        source={require("../assets/ellipse-9.png")}
      />
      <Text style={[styles.akshayVerma, styles.textClr]}>Akshay Verma</Text>
      <Text style={[styles.electronicsHome, styles.text2Position]}>
        Electronics , Home Decor , Accessories
      </Text>
      <Text style={[styles.text1, styles.text1Position]}>
        <Text style={styles.textTypo}>{`< `}</Text>
        <Text style={styles.text3Typo}>₹</Text>
        <Text style={styles.textTypo}> 50,000</Text>
      </Text>
      <Text style={[styles.interests, styles.allTypo]}>Interests</Text>
      <Text style={[styles.budgetRange, styles.allTypo]}>Budget Range</Text>
      <Text style={[styles.bidsHistory, styles.bidsHistoryPosition]}>
        Bids History
      </Text>
      <Text style={[styles.all, styles.allTypo]}>All</Text>
      <Text style={[styles.banglore, styles.allTypo]}>Bangalore</Text>
      <TouchableOpacity onPress={() => navigation.navigate('CreateAuction')}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Text style={[styles.inviteToBid, styles.text5Typo]}>
          Bid
        </Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate('SignIn')}>
        <View style={[styles.rectangleParent1, styles.groupChildLayout1]}>
        
          <View style={styles.groupChild1} />
          <Text style={[styles.logout1, styles.text5Typo]}>
            LOGOUT
          </Text>
        </View>
      </TouchableOpacity>
      <View style={styles.parent}>
        <Text style={[styles.text5, styles.text5Typo]}>6</Text>
        <Text style={[styles.auctionWins, styles.allTypo]}>Auction Wins</Text>
      </View>
      <Image
        style={[styles.rectangleIcon, styles.home2ItemLayout]}
        resizeMode="cover"
        source={require("../assets/rectangle-30.png")}
      />
      <Text style={[styles.macbookAir13, styles.textClr]}>MacBook Air 13</Text>
      <Text style={[styles.samsungS215g, styles.text6Typo]}>
        Samsung S21+ 5G
      </Text>
      <Text style={[styles.text6, styles.text6Typo]}>₹ 38,000</Text>
      <Image
        style={[styles.mditickCircleIcon, styles.mditickIconLayout]}
        resizeMode="cover"
        source={require("../assets/mditickcircle.png")}
      />
      <Image
        style={[styles.mditickCircleIcon1, styles.mditickIconLayout]}
        resizeMode="cover"
        source={require("../assets/mditickcircle.png")}
      />
      <Image
        style={styles.home2Child2}
        resizeMode="cover"
        source={require("../assets/ellipse-241.png")}
      />
      <TouchableOpacity onPress={() => navigation.navigate('Main')}>
        <Image
          style={[styles.iconlyboldarrowLeft2, styles.bidsHistoryPosition]}
          resizeMode="cover"
          source={require("../assets/iconlyboldarrow--left-2.png")}
        />
      </TouchableOpacity>
      <View style={styles.cont}>
        <TouchableOpacity onPress={() => navigation.navigate('Main')}>
          <Image
            style={styles.contIcon}
            resizeMode="cover"
            source={require("../assets/mingcutehome3fill.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Favourites')}>
          <Image
            style={styles.contIcon}
            resizeMode="cover"
            source={require("../assets/iconamoonheartfill.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Wallet')}>
          <Image
            style={styles.contIcon}
            resizeMode="cover"
            source={require("../assets/entypowallet.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Home2')}>
          <Image
            style={styles.contIcon1}
            resizeMode="cover"
            source={require("../assets/exclude.png")}
          />
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  textClr: {
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
  },
  allTypo1: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  home2ItemLayout: {
    left: 50,
    height: 100,
    width: 360,
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  text3Typo: {
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
  },
  text1Position: {
    fontSize: FontSize.size_mini,
    textAlign: "left",
    top: 467,
    color: Color.colorWhite,
    left: "48%",
    marginLeft: -161,
    position: "absolute",
  },
  allTypo: {
    color: Color.colorLightgray_100,
    textAlign: "left",
    fontSize: 17,
  },
  bidsHistoryPosition: {
    top: 497,
    position: "absolute",
  },
  groupChildLayout: {
    height: 36,
    width: 105,
    position: "absolute",
  },
 
  text5Typo: {
    fontSize: 17,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  text6Typo: {
    top: 750,
    textAlign: "left",
    color: Color.colorWhite,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_xs,
    left: "50%",
    position: "absolute",
  },
  mditickIconLayout: {
    height: 24,
    width: 24,
    left: 370,
    position: "absolute",
  },
  home2Child: {
    top: 530,
    height: 100,
    width: 360,
    borderRadius: Border.br_3xs,
    left: "46%",
    marginLeft: -161,
    position: "absolute",
  },
  text: {
    top: 600,
    left: 300,
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  unionIcon: {
    width: 6,
    height: 11,
    top: 603,
    left: 355,
    position: "absolute",
  },
  h36m: {
    top: 528,
    left: 290,
    letterSpacing: 0.1,
    color: Color.colorGray_300,
    textAlign: "left",
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  home2Item: {
    top: 800,
    position: "absolute",
  },
  buyerProfile: {
    marginLeft: -90,
    top: 47,
    fontSize: FontSize.size_lg,
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
    left: "50%",
  },
  ellipseIcon: {
    marginLeft: -66,
    top: 102,
    width: 131,
    height: 131,
    left: "50%",
    position: "absolute",
  },
  akshayVerma: {
    marginLeft: -90,
    top: 250,
    fontSize: 17,
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    left: "52%",
  },
  electronicsHome: {
    top: 360,
    width: 500,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    left:50,
    fontSize:16,
    color: Color.colorWhite,
  },
  textTypo: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  text1: {
    top: 454,
  },
  interests: {
    top: 370,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorLightgray_100,
    left: "46%",
    marginLeft: -161,
    position: "absolute",
  },
  budgetRange: {
    top: 439,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorLightgray_100,
    left: "45%",
    marginLeft: -161,
    position: "absolute",
  },
  bidsHistory: {
    color: Color.colorLightgray_100,
    textAlign: "left",
    fontSize: 18,
    fontFamily: FontFamily.poppinsRegular,
    left: "47%",
    marginLeft: -161,
  },
  all: {
    marginLeft: 123,
    top: 498,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
    left: "56%",
  },
  banglore: {
    marginLeft: -50,
    top: 275,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorLightgray_100,
    left: "48%",
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.colorHotpink,
    top: 260,
    left: 300,
    borderRadius: Border.br_3xs,
    width: 105,
  },

  logout1:{
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorWhite,
    fontWeight:"bold",
    left:360,
    top:-50,
  },
 
  inviteToBid: {
    top: 263,
    left: 335,
  },
  rectangleParent: {
    top: 320,
    left: 255,
  },
  text5: {
    marginLeft: 40,
    top: 30,
    left: "55%",
  },
  auctionWins: {
    top: 30,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorLightgray_100,
    left: -70,
    width:200,
    position: "absolute",
  },
  parent: {
    marginLeft: -109,
    top: 299,
    width: 78,
    height: 39,
    left: "50%",
    position: "absolute",
  },
  jammenuIcon: {
    top: 39,
    left: 395,
    width: 41,
    height: 41,
    position: "absolute",
    overflow: "hidden",
  },
  rectangleIcon: {
    top: 670,
  },
  macbookAir13: {
    top: 610,
    lineHeight: 12,
    width: 108,
    marginLeft: -153,
    textAlign: "left",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_xs,
    left: "50%",
  },
  samsungS215g: {
    marginLeft: -153,
  },
  text6: {
    marginLeft: 84,
  },
  mditickCircleIcon: {
    top: 660,
  },
  mditickCircleIcon1: {
    top: 790,
  },
  home2Child1: {
    marginLeft: 121,
    top: 895,
    width: 30,
    height: 30,
    left: 250,
    position: "absolute",
  },
  home2Child2: {
    marginLeft: -73,
    top: 94,
    width: 146,
    height: 146,
    left: "50%",
    position: "absolute",
  },
  iconlyboldarrowLeft2: {
    left: 350,
    width: 20,
    height: 20,
  },
  cont: {
    flexDirection: "row",
    justifyContent: "space-around",
    position: "absolute",
    bottom: 0,
    width: "100%",
    height:65,
    backgroundColor: Color.colorDarkslategray,
    paddingVertical: 10,
  },
  contIcon: {
    width: 33,
    height: 33,
  },
  pharrowDownBoldIcon:{
    top:40,
    left:30,
  },
  home2: {
    flex: 1,
    width: "100%",
    height: 800,
    backgroundColor: Color.bG,
    overflow: "hidden",
  },
 
});

export default Home1;


