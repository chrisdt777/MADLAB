import * as React from "react";
import { Image, StyleSheet, View, Text, TouchableOpacity, TextInput , ScrollView } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";
import { useNavigation } from '@react-navigation/native';

const ForgotPassword = () => {

  const navigation = useNavigation();

  const handleNextPress = () => {
    navigation.navigate('ForgotPassword1');
  };

  return (
    <LinearGradient
      style={styles.forgotPassword}
      locations={[0, 0.89]}
      colors={["#43427a", "#272841"]}
      useAngle={true}
      angle={180}
    >
      <Image
        style={styles.forgotPasswordChild}
        resizeMode="cover"
        source={require("../assets/ellipse-25.png")}
      />
      <Image
        style={[styles.forgotPasswordItem, styles.forgotLayout]}
        resizeMode="cover"
        source={require("../assets/ellipse-22.png")}
      />
      <Image
        style={styles.forgotPasswordInner}
        resizeMode="cover"
        source={require("../assets/ellipse-21.png")}
      />
      <Image
        style={styles.ellipseIcon}
        resizeMode="cover"
        source={require("../assets/ellipse-15.png")}
      />
      <Image
        style={[styles.forgotPasswordChild1, styles.forgotLayout]}
        resizeMode="cover"
        source={require("../assets/ellipse-23.png")}
      />
      <Image
        style={styles.forgotPasswordChild2}
        resizeMode="cover"
        source={require("../assets/ellipse-201.png")}
      />
      <View style={styles.inputContainer}>
  
  <View style={styles.inputBox}>
    <TextInput
      style={styles.inputText}
      placeholder="Email or Phone Number"
      placeholderTextColor={Color.colorBlack}
    />
  </View>
  
  
</View>

      
     
      
      <View style={styles.forgotPasswordWrapper}>
        <Text style={[styles.forgotPassword1, styles.nextClr]}>
          Forgot Password ?
        </Text>
      </View>
      <Image
        style={styles.flatColorIconsgoogle}
        resizeMode="cover"
        source={require("../assets/flatcoloriconsgoogle.png")}
      />
      <Image
        style={styles.icbaselineAppleIcon}
        resizeMode="cover"
        source={require("../assets/icbaselineapple.png")}
      />
      <Text style={[styles.relaxWe, styles.relaxWeFlexBox]}>
        Relax , We Got it Covered !
      </Text>
      <TouchableOpacity onPress={handleNextPress} style={styles.rectangleParent}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Text style={[styles.next]}>Next</Text>
      </TouchableOpacity>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  forgotLayout: {
    height: 27,
    width: 27,
    position: "absolute",
  },
  relaxWeFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  nextClr: {
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
  },
  groupChildLayout: {
    height: 36,
    width: 101,
    position: "absolute",
  },
  forgotPasswordChild: {
    top: -141,
    left: -93,
    width: 453,
    height: 447,
    position: "absolute",
  },
  forgotPasswordItem: {
    top: 66,
    left: 204,
  },
  forgotPasswordInner: {
    top: 121,
    left: 192,
    width: 41,
    height: 41,
    position: "absolute",
  },
  ellipseIcon: {
    top: 36,
    left: 236,
    width: 85,
    height: 85,
    position: "absolute",
  },
  forgotPasswordChild1: {
    top: 30,
    left: 187,
  },
  forgotPasswordChild2: {
    top: 88,
    left: 292,
    width: 49,
    height: 49,
    position: "absolute",
  },
  rectangleView: {
    top: 575,
    backgroundColor: Color.colorGray_100,
    width: 400,
    height: 50,
    borderRadius: Border.br_3xs,
    left: 30,
    position: "absolute",
  },
  emailOrPhone: {
    top: 588,
    left: 48,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorBlack,
    width: 188,
    opacity: 0.6,
    fontSize: FontSize.size_mini,
  },
  forgotPassword1: {
    fontSize: FontSize.size_16xl,
    lineHeight: 44,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    left: 0,
    top:-20,
    width: 298,
  },
  forgotPasswordWrapper: {
    top: 448,
    height: 88,
    width: 268,
    left: 30,
    position: "absolute",
  },
  flatColorIconsgoogle: {
    top: 545,
    left: 345,
    width: 28,
    height: 28,
    position: "absolute",
    overflow: "hidden",
  },
  icbaselineAppleIcon: {
    top: 540,
    left: 385,
    width: 32,
    height: 32,
    position: "absolute",
    overflow: "hidden",
  },
  relaxWe: {
    top: 545,
    fontSize: FontSize.size_smi,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorLightslategray_200,
    left: 30,
  },
  groupChild: {
    backgroundColor: Color.colorHotpink,
    left: 0,
    top: 0,
    borderRadius: Border.br_3xs,
  },
  next: {
    top: 5,
    left: -2,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    fontSize: FontSize.size_mini,
    color: Color.colorWhite,
    textAlign: "center",
    width: '100%',
    height: '100%'
  },
  rectangleParent: {
    top: 657,
    left: 30,
    height: 36,
    width: 101,
    position: "absolute",
    justifyContent: 'center',
    alignItems: 'center',
  },
  inputBox: {
    width: 400,
    height: 50,
    top:570,
    left:30,
    backgroundColor: Color.colorGray_100,
    borderRadius: Border.br_3xs,
    marginVertical: 10,
    justifyContent: "center",
    paddingHorizontal: 10,
  },
  inputText: {
    opacity: 0.6,
    color: Color.colorBlack,
    fontFamily: FontFamily.poppinsRegular,
  },
  forgotPassword: {
    flex: 1,
    width: "100%",
    height: 800,
    backgroundColor: Color.bG,
    overflow: "hidden",
  },
});

export default ForgotPassword;
