import * as React from "react";
import { Image, StyleSheet, View, Text, TextInput, ScrollView, TouchableOpacity } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useNavigation } from "@react-navigation/native"; // Import navigation hooks
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const PlaceABid = () => {
  const navigation = useNavigation(); // Navigation hook

  const handleBid = () => {
    // Handle bid action here
    navigation.navigate("Main"); // Navigate to the main page upon bidding
  };

  return (
    <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
      <View style={styles.container}>
        <Image
          style={styles.backgroundImage}
          resizeMode="cover"
          source={require("../assets/liveauction_blurred.png")}
        />
        <View style={styles.overlay} />
        <LinearGradient
          style={styles.gradient}
          locations={[0, 0.89]}
          colors={["#43427a", "#272841"]}
          useAngle={true}
          angle={180}
        >
          <View style={styles.content}>
            <View style={[styles.placeABidChild, styles.placeLayout1]} />
            <View style={[styles.placeABidItem, styles.placeLayout1]} />
            <Text style={[styles.topBidder, styles.topBidderFlexBox1]}>
              Top Bidder
            </Text>
            <Image
              style={[styles.placeABidInner, styles.placeLayout]}
              resizeMode="cover"
              source={require("../assets/ellipse-61.png")}
            />
            <Image
              style={[styles.ellipseIcon, styles.placeLayout]}
              resizeMode="cover"
              source={require("../assets/ellipse-72.png")}
            />
            <Image
              style={[styles.placeABidChild1, styles.placeLayout]}
              resizeMode="cover"
              source={require("../assets/ellipse-8.png")}
            />
            <Text style={[styles.aaravSharma, styles.meeraReddyTypo]}>
              Aarav Sharma
            </Text>
            <Text style={[styles.meeraReddy, styles.meeraReddyTypo]}>
              Meera Reddy
            </Text>
            <Text style={[styles.rohanDesai, styles.meeraReddyTypo]}>
              Rohan Desai
            </Text>
            <Text style={[styles.text, styles.bidTypo]}>₹ 35,000</Text>
            <Text style={[styles.text1, styles.bidTypo]}>₹ 30,000</Text>
            <Text style={[styles.text2, styles.bidTypo]}>₹ 28,000</Text>
            <Text style={[styles.yourBid, styles.bidTypo]}>Your Bid</Text>
            <View style={[styles.lineView, styles.placeChildLayout]} />
            <View style={[styles.placeABidChild2, styles.placeChildLayout]} />
            <View style={[styles.placeABidChild3, styles.placeChildLayout]} />
            <View style={styles.rectangleView} />
            <TextInput
              style={[styles.enterYourBid, styles.topBidderFlexBox]}
              placeholder="Enter your bid"
              placeholderTextColor={Color.colorGray_200}
              keyboardType="numeric"
            />
            <TouchableOpacity
              style={[styles.rectangleParent, styles.groupChildLayout]}
              onPress={handleBid}
            >
              <View style={[styles.groupChild, styles.groupChildLayout]} />
              <Text style={[styles.bid, styles.bidTypo]}>Bid</Text>
            </TouchableOpacity>
            <Image
              style={styles.image20Icon}
              resizeMode="cover"
              source={require("../assets/image-201.png")}
            />
          </View>
        </LinearGradient>
      </View>
    </ScrollView>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: "100%",
    height: "100%",
    backgroundColor: Color.bG,
  },
  backgroundImage: {
    width: "100%",
    height: "100%",
    position: "absolute",
  },
  overlay: {
    position: "absolute",
    width: "100%",
    height: "100%",
    backgroundColor: "rgba(0, 0, 0, 0.3)", // Adjust the opacity as needed
  },
  gradient: {
    flex: 1,
    justifyContent: "flex-start", // Changed from "center"
    alignItems: "flex-start", // Changed from "center"
    paddingLeft: 45, // Added padding to the left
    paddingTop: 20, // Added padding to the top
  },
  content: {
    width: "100%", // Ensure the content takes full width
    paddingLeft: 20, // Added padding to the left
  },
  placeLayout1: {//background transperent 
    height: 720,
    width: 390,
    borderRadius: Border.br_3xs,
    position: "absolute",
    top:80,
    left: -13, // Positioned to the left
  },
  topBidderFlexBox1: {//top bidder
    textAlign: "left",
    position: "absolute",
    left: 30, // Positioned to the left
  },
  topBidderFlexBox: {
    left:30,
  },
  placeLayout: {//profile pic
    height: 34,
    width: 34,
    left: 25, // Positioned to the left
    position: "absolute",
  },
  meeraReddyTypo: {//customer name
    color: Color.colorWhite,
    fontSize: FontSize.size_mini,
    left: 70, // Adjusted to align with new layout
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  bidTypo: {
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
    color: Color.colorWhite,
    textAlign: "left",
    position: "absolute",
  },
  placeChildLayout: {
    height: 0,
    width: 300,
    borderTopWidth: 0.4,
    borderColor: Color.colorLightslategray_100,
    borderStyle: "solid",
    position: "absolute",
    left: 30, // Positioned to the left
  },
  groupChildLayout: {
    width: 109,
    height: 59,
    position: "absolute",
  },
  placeABidChild: {
    marginLeft: 0, // Adjusted margin
    left: 0, // Positioned to the left
    backgroundColor: Color.colorDarkslateblue,
  },
  placeABidItem: {
    left: 0, // Positioned to the left
    backgroundColor: Color.colorSteelblue_300,
  },
  topBidder: {
    top: 410,
    fontSize: 17,
    color: Color.colorLightgray_100,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
  },
  placeABidInner: {
    top: 455,
  },
  ellipseIcon: {
    top: 510,
  },
  placeABidChild1: {
    top: 565,
  },
  aaravSharma: {
    top: 460,
  },
  meeraReddy: {
    top: 515,
  },
  rohanDesai: {
    top: 570,
  },
  text: {
    fontSize: FontSize.size_base,
    fontWeight: "700",
    left: 270, // Adjusted to align with new layout
    top: 460,
  },
  text1: {
    fontSize: FontSize.size_base,
    fontWeight: "700",
    left: 270, // Adjusted to align with new layout
    top: 515,
  },
  text2: {
    fontSize: FontSize.size_base,
    fontWeight: "700",
    left: 270, // Adjusted to align with new layout
    top: 570,
  },
  yourBid: {
    top: 635,
    fontSize: FontSize.size_base,
    fontWeight: "700",
    left: 30, // Positioned to the left
  },
  lineView: {//lines
    top: 500,
  },
  placeABidChild2: {
    top: 555,
  },
  placeABidChild3: {
    top: 610,
  },
  rectangleView: {
    backgroundColor: Color.colorSteelblue_200,
    borderColor: Color.colorThistle,
    borderWidth: 1,
    height: 59,
    top: 670,
    width: 300,
    borderStyle: "solid",
    left: 30, // Positioned to the left
    borderRadius: Border.br_3xs,
    position: "absolute",
  },
  enterYourBid: {
    top: 675, // Adjusted to position the TextInput inside the box
    left: 40, // Adjusted to align with new layout
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorGray_200,
    width: 220, // Adjusted width for TextInput
  },
  groupChild: {
    backgroundColor: Color.colorHotpink,
    width: 109,
    borderRadius: Border.br_3xs,
    left: 0,
    top: 0,
  },
  bid: {
    top: 12,
    left: 39,
    fontSize: FontSize.size_lg,
    width: 50,
    height: 26,
  },
  rectangleParent: {//bid box
    left: 222, // Positioned to the left
    top: 670,
    width: 109,
  },
  image20Icon: {
    top: 120,
    borderRadius: Border.br_mid,
    width: 262,
    height: 257,
    left: 40, // Positioned to the left
    position: "absolute",
  },
});

export default PlaceABid;
