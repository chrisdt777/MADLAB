import * as React from "react";
import { Image, StyleSheet, Text, View , TouchableOpacity } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useNavigation } from '@react-navigation/native';
import { Border, FontSize, Color, FontFamily } from "../GlobalStyles";

const Favourites = () => {
  const navigation = useNavigation();
  
  return (
    <LinearGradient
      style={styles.favourites}
      locations={[0, 0.89]}
      colors={["#43427a", "#272841"]}
      useAngle={true}
      angle={180}
    >
      <Image
        style={[styles.favouritesChild, styles.favouritesLayout]}
        resizeMode="cover"
        source={require("../assets/rectangle-11.png")}
      />
      <Image
        style={[styles.favouritesItem, styles.favouritesLayout]}
        resizeMode="cover"
        source={require("../assets/rectangle-16.png")}
      />
      
      <TouchableOpacity onPress={() => navigation.navigate('Main')}>
        <Image
          style={styles.pharrowDownBoldIcon}
          resizeMode="cover"
          source={require("../assets/pharrowdownbold.png")}
        />
      </TouchableOpacity>
      <Text style={[styles.favourites1, styles.favourites1Position]}>
        FAVOURITES
      </Text>
      <Text
        style={[styles.noteProductsWillContainer, styles.favourites1Position]}
      >
        <Text style={styles.noteTypo}>Note</Text>
        <Text style={styles.productsWillBe}>
          : Products will be automatically removed once the auction ends.
        </Text>
      </Text>
      <Image
        style={[styles.rectangleIcon, styles.rectangleIconPosition]}
        resizeMode="cover"
        source={require("../assets/rectangle-10.png")}
      />
      <Image
        style={[styles.favouritesChild1, styles.favouritesChildPosition1]}
        resizeMode="cover"
        source={require("../assets/rectangle-12.png")}
      />
      <Image
        style={[styles.iconamoonheartFill, styles.iconamoonheartLayout]}
        resizeMode="cover"
        source={require("../assets/iconamoonheartfill2.png")}
      />
    
      <Image
        style={[styles.favouritesChild2, styles.favouritesChildPosition]}
        resizeMode="cover"
        source={require("../assets/rectangle-14.png")}
      />
      <Image
        style={[styles.favouritesChild3, styles.favouritesChildPosition1]}
        resizeMode="cover"
        source={require("../assets/rectangle-13.png")}
      />
      <Image
        style={[styles.favouritesChild4, styles.favouritesChildPosition]}
        resizeMode="cover"
        source={require("../assets/rectangle-15.png")}
      />
      <Image
        style={[styles.heart]}
        resizeMode="cover"
        source={require("../assets/iconamoonheartfill2.png")}
      />
        <Image
        style={[styles.heart1]}
        resizeMode="cover"
        source={require("../assets/iconamoonheartfill2.png")}
      />
            <Image
        style={[styles.heart2]}
        resizeMode="cover"
        source={require("../assets/iconamoonheartfill2.png")}
      />
            <Image
        style={[styles.heart3]}
        resizeMode="cover"
        source={require("../assets/iconamoonheartfill2.png")}
      />
            <Image
        style={[styles.heart4]}
        resizeMode="cover"
        source={require("../assets/iconamoonheartfill2.png")}
      />
            <Image
        style={[styles.heart5]}
        resizeMode="cover"
        source={require("../assets/iconamoonheartfill2.png")}
      />
      <Image
        style={[styles.favouritesChild5, styles.rectangleIconPosition]}
        resizeMode="cover"
        source={require("../assets/rectangle-17.png")}
      />
      <View style={styles.cont}>
        <TouchableOpacity onPress={() => navigation.navigate('Main')}>
          <Image
            style={styles.contIcon}
            resizeMode="cover"
            source={require("../assets/mingcutehome3fill.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Favourites')}>
          <Image
            style={styles.contIcon}
            resizeMode="cover"
            source={require("../assets/iconamoonheartfill.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Wallet')}>
          <Image
            style={styles.contIcon}
            resizeMode="cover"
            source={require("../assets/entypowallet.png")}
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('Home2')}>
          <Image
            style={styles.contIcon1}
            resizeMode="cover"
            source={require("../assets/exclude.png")}
          />
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  favouritesLayout: {
    height: 230,
    width: 200,
    borderRadius: Border.br_mini,
    left: "50%",
    top: 720,
    position: "absolute",
  },
  favourites1Position: {
    textAlign: "left",
    left: "50%",
    position: "absolute",
  },
  rectangleIconPosition: {
    top: 158,
    height: 160,
    width: 200,
    borderRadius: Border.br_mini,
    left: "50%",
    position: "absolute",
  },
  favouritesChildPosition1: {
    top: 345,
    height: 160,
    width: 200,
    borderRadius: Border.br_mini,
    left: "50%",
    position: "absolute",
  },
  iconamoonheartLayout: {
    height: 22,
    width: 22,
    top: 279,
    position: "absolute",
    overflow: "hidden",
  },
  iconamoonheartPosition1: {
    top: 441,
    height: 22,
    width: 22,
    position: "absolute",
    overflow: "hidden",
  },
  favouritesChildPosition: {
    top: 535,
    height: 160,
    width: 200,
    borderRadius: Border.br_mini,
    left: "50%",
    position: "absolute",
  },
  iconamoonheartPosition: {
    top: 603,
    height: 22,
    width: 22,
    position: "absolute",
    overflow: "hidden",
  },
  favouritesChild: {
    marginLeft: 10,
  },
  favouritesItem: {
    marginLeft: -200,
   
  },


  pharrowDownBoldIcon: {
    top: 42,
    left: 18,
    width: 38,
    height: 38,
    position: "absolute",
    overflow: "hidden",
  },
  favourites1: {
    marginLeft: -54,
    top: 47,
    fontSize: FontSize.size_lg,
    color: Color.colorWhite,
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
  },
  noteTypo: {
    fontFamily: FontFamily.poppinsBold,
    fontWeight: "700",
  },
  productsWillBe: {
    fontWeight: "800",
    fontFamily: FontFamily.poppinsMedium,
  },
  noteProductsWillContainer: {
    marginLeft: -180,
    top: 108,
    fontSize: 16,
    lineHeight: 16,
    color: Color.colorLightgray_100,
    width: 370,
  },
  rectangleIcon: {
    marginLeft: -210,
  },
  favouritesChild1: {
    marginLeft: -205,
  },
  iconamoonheartFill: {
    left: 309,
  },
 
  favouritesChild2: {
    marginLeft: -201,
  },
  favouritesChild3: {
    marginLeft: 13,
  },
  favouritesChild4: {
    marginLeft: 10,
  },
  favouritesChild5: {
    marginLeft: 10,
  },
  iconamoonheartFill2: {
    left: 197,
  },
  iconamoonheartFill4: {
    left: 309,
  },
  iconamoonheartFill5: {
    left: 309,
  },
  iconamoonheartFill6: {
    left: 147,
  },
  cont: {
    flexDirection: "row",
    justifyContent: "space-around",
    position: "absolute",
    bottom: 0,
    width: "100%",
    height:65,
    backgroundColor: Color.colorDarkslategray,
    paddingVertical: 10,
  },
  contIcon: {
    width: 33,
    height: 33,
  },
  heart:{
    top:290,
    left:190,
  },
  heart1:{
    top:290,
    left:410,
    position:"absolute",
    zIndex:1,
  },
  heart2:{
    top:455,
    left:190,
   },
   heart3:{
    top:435,
    left:410,
   },
   heart4:{
    top:600,
    left:190,
   },
   heart5:{
    top:580,
    left:410,
   },

  favourites: {
    flex: 1,
    width: "100%",
    height: 800,
    backgroundColor: Color.bG,
    overflow: "hidden",
  },
});

export default Favourites;
