import * as React from "react";
import { Image, StyleSheet, Text, View, TouchableOpacity, TextInput, ScrollView } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";
import { useNavigation } from '@react-navigation/native';

const ForgotPassword1 = () => {
  const navigation = useNavigation();

  const handleLoginPress = () => {
    navigation.navigate('Main'); // Replace 'MainPage' with the actual route name for your main page
  };

  return (
    <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
      <LinearGradient
        style={styles.forgotPassword1}
        locations={[0, 0.89]}
        colors={["#43427a", "#272841"]}
        useAngle={true}
        angle={180}
      >
        {/* Background Images */}
        <Image
          style={styles.forgotPassword1Child}
          resizeMode="cover"
          source={require("../assets/ellipse-25.png")}
        />
        <Image
          style={[styles.forgotPassword1Item, styles.forgotLayout]}
          resizeMode="cover"
          source={require("../assets/ellipse-22.png")}
        />
        <Image
          style={styles.forgotPassword1Inner}
          resizeMode="cover"
          source={require("../assets/ellipse-21.png")}
        />
        <Image
          style={styles.ellipseIcon}
          resizeMode="cover"
          source={require("../assets/ellipse-15.png")}
        />
        <Image
          style={[styles.forgotPassword1Child1, styles.forgotLayout]}
          resizeMode="cover"
          source={require("../assets/ellipse-23.png")}
        />
        <Image
          style={styles.forgotPassword1Child2}
          resizeMode="cover"
          source={require("../assets/ellipse-20.png")}
        />

        {/* Enter OTP Text */}
        <View style={styles.enterOtpWrapper}>
          <Text style={[styles.enterOtp, styles.loginFlexBox]}>Enter OTP</Text>
        </View>

        {/* OTP Input Boxes */}
        <View style={styles.inputContainer}>
          {/* TextInput 1 for OTP */}
          <TextInput
            style={[styles.rectangleView, styles.forgotChildLayout]}
            placeholder="•"
            placeholderTextColor={Color.colorBlack}
            maxLength={1}
            keyboardType="numeric"
            onChangeText={(text) => {
              // handle OTP input for the second box
            }}
            color={Color.colorBlack}
            
          />
          <TextInput
            style={[styles.forgotPassword1Child3, styles.forgotChildLayout]}
            placeholder="•"
            placeholderTextColor={Color.colorBlack}
            maxLength={1}
            keyboardType="numeric"
            onChangeText={(text) => {
              // handle OTP input for the second box
            }}
            color={Color.colorBlack}
          />
          <TextInput
            style={[styles.forgotPassword1Child4, styles.forgotChildLayout]}
            placeholder="•"
            placeholderTextColor={Color.colorBlack}
            maxLength={1}
            keyboardType="numeric"
            onChangeText={(text) => {
              // handle OTP input for the third box
            }}
            color={Color.colorBlack}
          />
          <TextInput
            style={[styles.forgotPassword1Child5, styles.forgotChildLayout]}
            placeholder="•"
            placeholderTextColor={Color.colorBlack}
            maxLength={1}
            keyboardType="numeric"
            onChangeText={(text) => {
              // handle OTP input for the fourth box
            }}
            color={Color.colorBlack}
          />
        </View>

        {/* Login Button */}
        <TouchableOpacity onPress={handleLoginPress} style={styles.loginButton}>
          <Text style={styles.loginText}>Login</Text>
        </TouchableOpacity>
      </LinearGradient>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  forgotLayout: {
    height: 27,
    width: 27,
    position: "absolute",
  },
  loginFlexBox: {
    textAlign: "left",
    color: Color.colorWhite,
    position: "absolute",
  },
  forgotChildLayout: {
    height: 42,
    backgroundColor: Color.colorGray_100,
    top: 577,
    borderRadius: Border.br_3xs,
    width: 49,
    position: "absolute",
  },
  forgotPassword1Child: {
    top: -141,
    left: -93,
    width: 453,
    height: 447,
    position: "absolute",
  },
  forgotPassword1Item: {
    top: 66,
    left: 204,
  },
  forgotPassword1Inner: {
    top: 121,
    left: 192,
    width: 41,
    height: 41,
    position: "absolute",
  },
  ellipseIcon: {
    top: 36,
    left: 236,
    width: 85,
    height: 85,
    position: "absolute",
  },
  forgotPassword1Child1: {
    top: 30,
    left: 187,
  },
  forgotPassword1Child2: {
    top: 88,
    left: 292,
    height: 49,
    width: 49,
    position: "absolute",
  },
  enterOtp: {
    fontSize: FontSize.size_16xl,
    lineHeight: 44,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    left: -10,
    top: 0,
    color: Color.colorBlack,
    width: 500,
  },
  enterOtpWrapper: {
    top: 495,
    left: 145,
    height: 44,
    width: 175,
    position: "absolute",
  },
  rectangleView: {
    left: 50, // Adjust position as needed
  },
  forgotPassword1Child3: {
    left: 150, // Adjust position as needed
  },
  forgotPassword1Child4: {
    left: 250, // Adjust position as needed
  },
  forgotPassword1Child5: {
    left: 350, // Adjust position as needed
  },
  loginButton: {
    backgroundColor: Color.colorHotpink,
    borderRadius: Border.br_3xs,
    width: 101,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
    position: "absolute",
    top: 660,
    left: 40,
  },
  loginText: {
    color: Color.colorWhite,
    fontSize: FontSize.size_mini,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    textAlign: 'center',
    width: '100%',
  },
  forgotPassword1: {
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
    backgroundColor: Color.bG,
  },
});

export default ForgotPassword1;
