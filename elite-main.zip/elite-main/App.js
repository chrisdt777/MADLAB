const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";

import Home from "./screens/Home";
import Welcome from "./screens/Welcome";
import Welcome1 from "./screens/Welcome1";
import ForgotPassword from "./screens/ForgotPassword";
import Ellipse from "./components/Ellipse";
import CreateAccount from "./screens/CreateAccount";
import SignIn from "./screens/SignIn";
import Image1 from "./components/Image1";
import Home1 from "./screens/Home1";
import Home2 from "./screens/Home2";
import SellerProfile from "./screens/SellerProfile";
import CreateAuction from "./screens/CreateAuction";
import Main from "./screens/Main";
import LiveAuction from "./screens/LiveAuction";
import PlaceABid from "./screens/PlaceABid";
import Wallet from "./screens/Wallet";
import Favourites from "./screens/Favourites";
import Group from "./components/Group";
import CreateAccount1 from "./screens/CreateAccount1";
import ForgotPassword1 from "./screens/ForgotPassword1";
import Size48Image from "./components/Size48Image";
import Size48Image1 from "./components/Size48Image1";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen
              name="Home"
              component={Home}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Welcome"
              component={Welcome}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Welcome1"
              component={Welcome1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ForgotPassword"
              component={ForgotPassword}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CreateAccount"
              component={CreateAccount}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SignIn"
              component={SignIn}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Home1"
              component={Home1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Home2"
              component={Home2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SellerProfile"
              component={SellerProfile}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CreateAuction"
              component={CreateAuction}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Main"
              component={Main}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="LiveAuction"
              component={LiveAuction}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="PlaceABid"
              component={PlaceABid}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Wallet"
              component={Wallet}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Favourites"
              component={Favourites}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="CreateAccount1"
              component={CreateAccount1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ForgotPassword1"
              component={ForgotPassword1}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
    </>
  );
};
export default App;
