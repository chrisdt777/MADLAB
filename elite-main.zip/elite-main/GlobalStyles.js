/* fonts */
export const FontFamily = {
  poppinsRegular: "Poppins-Regular",
  poppinsSemiBold: "Poppins-SemiBold",
  poppinsBold: "Poppins-Bold",
  poppinsMedium: "Poppins-Medium",
};
/* font sizes */
export const FontSize = {
  size_base: 16,
  size_16xl: 35,
  size_lg: 18,
  size_mini: 15,
  size_smi: 13,
  size_sm: 14,
  size_xs: 12,
  size_3xs: 10,
  size_2xs: 11,
};
/* Colors */
export const Color = {
  colorWhite: "#fff",
  colorLightslategray_100: "#8d8fb8",
  colorLightslategray_200: "#8183ac",
  colorHotpink: "#fe77b1",
  colorBlack: "#000",
  colorGray_100: "#fafafa",
  colorGray_200: "rgba(255, 255, 255, 0.74)",
  colorGray_300: "rgba(255, 255, 255, 0.72)",
  colorLightgray_100: "#dad4da",
  colorLightgray_200: "rgba(218, 212, 218, 0.6)",
  colorSlategray: "#72749b",
  colorDarkslategray: "#3f4058",
  colorSteelblue_100: "#5c5c8d",
  colorSteelblue_200: "rgba(108, 108, 154, 0.59)",
  colorSteelblue_300: "rgba(108, 108, 154, 0.65)",
  colorDarkslateblue: "#404075",
  colorGainsboro_100: "rgba(217, 217, 217, 0.54)",
  colorThistle: "#bcb2c5",
};
/* border radiuses */
export const Border = {
  br_3xs: 10,
  br_8xs: 5,
  br_12xs_7: 1,
  br_xl: 20,
  br_mini: 15,
  br_12xs_6: 1,
  br_mid: 17,
};
